<?php 
 // created: 2014-04-28 12:40:51
$mod_strings['LBL_ENTERPRISE_ID'] = 'ooba Product Code';

?>
