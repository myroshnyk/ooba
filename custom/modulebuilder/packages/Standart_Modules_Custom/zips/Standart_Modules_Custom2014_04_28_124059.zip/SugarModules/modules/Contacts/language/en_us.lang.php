<?php 
 // created: 2014-04-28 12:40:47
$mod_strings['LBL_SACITIZEN'] = 'SA Citizen';
$mod_strings['LBL_LAST_CREDIT_CHECK_PERFORMED'] = 'Last Credit Check Performed';

?>
