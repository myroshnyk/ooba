<?php
 // created: 2014-04-25 18:17:38
$dictionary['Contact']['fields']['primary_address_country']['required']=false;
$dictionary['Contact']['fields']['primary_address_country']['comments']='Country for primary address';
$dictionary['Contact']['fields']['primary_address_country']['merge_filter']='disabled';
$dictionary['Contact']['fields']['primary_address_country']['calculated']=false;

 ?>