<?php
 // created: 2014-04-25 18:18:07
$dictionary['Contact']['fields']['alt_address_country']['required']=false;
$dictionary['Contact']['fields']['alt_address_country']['comments']='Country for alternate address';
$dictionary['Contact']['fields']['alt_address_country']['merge_filter']='disabled';
$dictionary['Contact']['fields']['alt_address_country']['calculated']=false;

 ?>