<?php
 // created: 2014-04-28 05:08:43
$dictionary['Opportunity']['fields']['sales_consultant_c']['labelValue']='Prequalification Expert';
$dictionary['Opportunity']['fields']['sales_consultant_c']['dependency']='';

 ?>