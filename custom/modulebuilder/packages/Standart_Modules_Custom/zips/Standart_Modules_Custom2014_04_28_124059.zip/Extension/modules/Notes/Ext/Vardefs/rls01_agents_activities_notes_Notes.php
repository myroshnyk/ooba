<?php
// created: 2014-04-25 15:05:05
$dictionary["Note"]["fields"]["rls01_agents_activities_notes"] = array (
  'name' => 'rls01_agents_activities_notes',
  'type' => 'link',
  'relationship' => 'rls01_agents_activities_notes',
  'source' => 'non-db',
  'module' => 'rls01_Agents',
  'bean_name' => false,
  'vname' => 'LBL_RLS01_AGENTS_ACTIVITIES_NOTES_FROM_RLS01_AGENTS_TITLE',
);
