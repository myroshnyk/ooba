<?php 
 // created: 2014-04-23 12:50:35
$mod_strings['LBL_PRODUCT_PRODUCTTEMPLATE_ID'] = 'Product (related  ID)';
$mod_strings['LBL_PRODUCT'] = 'Product';
$mod_strings['LBL_STATUS'] = 'Status';
$mod_strings['LBL_AGENCY'] = 'Agency';
$mod_strings['LBL_EA_BRANCH'] = 'EA Branch';
$mod_strings['LBL_SALES_TERRITORY'] = 'Sales Territory';
$mod_strings['LBL_REF_NUMBER'] = 'Ref Number';
$mod_strings['LBL_PREQUALIFICATION_EXPERT_USER_ID'] = 'Prequalification Expert (related User ID)';
$mod_strings['LBL_PREQUALIFICATION_EXPERT'] = 'Prequalification Expert';
$mod_strings['LBL_LEAD_PROVIDER_CONTACT_ID'] = 'Lead Provider (related Contact ID)';
$mod_strings['LBL_LEAD_PROVIDER'] = 'Lead Provider';
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';
$mod_strings['LBL_CAMPAIGN_CAMPAIGN_ID'] = 'Campaign (related Campaign ID)';
$mod_strings['LBL_CAMPAIGN'] = 'Campaign';
$mod_strings['LBL_DESCRIPTION'] = 'Comments';
$mod_strings['LBL_DESIRED_AMOUNT'] = 'Desired Amount';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Source';
$mod_strings['LBL_AGENCY_RLS01_AGENCIES_ID'] = 'Agency (related  ID)';
$mod_strings['LBL_EA_BRANCH_RLS01_BRANCHES_ID'] = 'EA Branch (related  ID)';
$mod_strings['LBL_REFFERER_RLS01_RESOURCES_ID'] = 'Refferer (related  ID)';
$mod_strings['LBL_REFFERER'] = 'Refferer';

?>
