<?php
 // created: 2014-04-28 04:58:06
$dictionary['Lead']['fields']['bond_status_c']['labelValue']='Bond Status';
$dictionary['Lead']['fields']['bond_status_c']['enforced']='';
$dictionary['Lead']['fields']['bond_status_c']['dependency']='';

 ?>