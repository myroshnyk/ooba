<?php 
 // created: 2014-04-23 12:50:25
$mod_strings['LBL_DET_IS_TEMPLATE'] = 'Template';
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';
$mod_strings['LBL_LAST_REVISION_CREATE_DATE'] = 'Last Revision Create Date';
$mod_strings['LBL_TEMPLATE_TYPE'] = 'Document Type';
$mod_strings['LBL_DOC_STATUS'] = 'Status:';

?>
