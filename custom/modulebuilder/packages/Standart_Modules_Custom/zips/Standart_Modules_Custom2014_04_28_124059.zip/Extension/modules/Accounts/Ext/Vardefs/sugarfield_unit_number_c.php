<?php
 // created: 2014-04-28 04:58:05
$dictionary['Account']['fields']['unit_number_c']['labelValue']='Unit Number';
$dictionary['Account']['fields']['unit_number_c']['enforced']='';
$dictionary['Account']['fields']['unit_number_c']['dependency']='';

 ?>