<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['citizenship_c']['labelValue']='Citizenship';
$dictionary['Contact']['fields']['citizenship_c']['dependency']='';
$dictionary['Contact']['fields']['citizenship_c']['visibility_grid']='';

 ?>