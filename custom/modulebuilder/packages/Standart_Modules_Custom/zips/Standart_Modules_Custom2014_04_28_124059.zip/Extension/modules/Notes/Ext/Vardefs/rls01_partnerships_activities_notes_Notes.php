<?php
// created: 2014-04-25 15:05:06
$dictionary["Note"]["fields"]["rls01_partnerships_activities_notes"] = array (
  'name' => 'rls01_partnerships_activities_notes',
  'type' => 'link',
  'relationship' => 'rls01_partnerships_activities_notes',
  'source' => 'non-db',
  'module' => 'rls01_Partnerships',
  'bean_name' => false,
  'vname' => 'LBL_RLS01_PARTNERSHIPS_ACTIVITIES_NOTES_FROM_RLS01_PARTNERSHIPS_TITLE',
);
