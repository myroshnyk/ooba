<?php
 // created: 2014-04-25 18:13:52
$dictionary['Account']['fields']['billing_address_country']['required']=false;
$dictionary['Account']['fields']['billing_address_country']['comments']='The country used for the billing address';
$dictionary['Account']['fields']['billing_address_country']['merge_filter']='disabled';
$dictionary['Account']['fields']['billing_address_country']['calculated']=false;

 ?>