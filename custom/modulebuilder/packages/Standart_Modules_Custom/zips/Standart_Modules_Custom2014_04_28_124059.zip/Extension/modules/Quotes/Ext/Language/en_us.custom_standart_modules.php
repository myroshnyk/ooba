<?php 
 // created: 2014-04-26 14:20:38
$mod_strings['LBL_REQUEST_PRODUCT_SEARCH'] = 'Request Product Search';
$mod_strings['LBL_CONVERT_INSTALLED_PRODUCT'] = 'Convert to Installed Product';

?>
