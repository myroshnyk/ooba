<?php
 // created: 2014-04-28 04:58:07
$dictionary['Quote']['fields']['desired_amount_c']['labelValue']='Desired Amount';
$dictionary['Quote']['fields']['desired_amount_c']['enforced']='';
$dictionary['Quote']['fields']['desired_amount_c']['dependency']='';

 ?>