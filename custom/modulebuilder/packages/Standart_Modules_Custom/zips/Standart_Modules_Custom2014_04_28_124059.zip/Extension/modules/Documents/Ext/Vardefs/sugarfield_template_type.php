<?php
 // created: 2014-04-23 11:17:06
$dictionary['Document']['fields']['template_type']['options']='doc_type_list';
$dictionary['Document']['fields']['template_type']['merge_filter']='disabled';
$dictionary['Document']['fields']['template_type']['calculated']=false;
$dictionary['Document']['fields']['template_type']['dependency']=false;

 ?>