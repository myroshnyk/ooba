<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['suburb_post_office_c']['labelValue']='Suburb / post office';
$dictionary['Contact']['fields']['suburb_post_office_c']['dependency']='';

 ?>