<?php

unset($layout_defs['Accounts']['subpanel_setup']['cases']);
unset($layout_defs['Accounts']['subpanel_setup']['accounts']);
unset($layout_defs['Accounts']['subpanel_setup']['leads']);
unset($layout_defs['Accounts']['subpanel_setup']['campaigns']);

?>