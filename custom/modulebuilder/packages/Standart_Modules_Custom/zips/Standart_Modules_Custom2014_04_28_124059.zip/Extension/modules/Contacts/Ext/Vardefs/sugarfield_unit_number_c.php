<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['unit_number_c']['labelValue']='Unit Number';
$dictionary['Contact']['fields']['unit_number_c']['enforced']='';
$dictionary['Contact']['fields']['unit_number_c']['dependency']='';

 ?>