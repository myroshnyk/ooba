<?php
 // created: 2014-04-28 04:58:06
$dictionary['Document']['fields']['last_revision_create_date_c']['labelValue']='Last Revision Create Date';
$dictionary['Document']['fields']['last_revision_create_date_c']['enforced']='';
$dictionary['Document']['fields']['last_revision_create_date_c']['dependency']='';

 ?>