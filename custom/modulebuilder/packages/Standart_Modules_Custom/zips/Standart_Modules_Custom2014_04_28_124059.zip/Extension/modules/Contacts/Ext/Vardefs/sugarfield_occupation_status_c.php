<?php
 // created: 2014-04-28 05:35:35
$dictionary['Contact']['fields']['occupation_status_c']['labelValue']='Occupation Status';
$dictionary['Contact']['fields']['occupation_status_c']['dependency']='';
$dictionary['Contact']['fields']['occupation_status_c']['visibility_grid']='';

 ?>