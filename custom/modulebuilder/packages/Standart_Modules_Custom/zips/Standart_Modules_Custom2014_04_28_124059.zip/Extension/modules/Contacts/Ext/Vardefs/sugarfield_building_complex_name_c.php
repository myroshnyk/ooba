<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['building_complex_name_c']['labelValue']='Building / Complex Name';
$dictionary['Contact']['fields']['building_complex_name_c']['enforced']='';
$dictionary['Contact']['fields']['building_complex_name_c']['dependency']='';

 ?>