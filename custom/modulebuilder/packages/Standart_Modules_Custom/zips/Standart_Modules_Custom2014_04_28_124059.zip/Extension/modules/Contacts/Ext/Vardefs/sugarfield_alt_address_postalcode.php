<?php
 // created: 2014-04-25 18:17:59
$dictionary['Contact']['fields']['alt_address_postalcode']['required']=false;
$dictionary['Contact']['fields']['alt_address_postalcode']['comments']='Postal code for alternate address';
$dictionary['Contact']['fields']['alt_address_postalcode']['merge_filter']='disabled';
$dictionary['Contact']['fields']['alt_address_postalcode']['calculated']=false;

 ?>