<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['sales_territory_c']['labelValue']='Sales Territory';
$dictionary['Opportunity']['fields']['sales_territory_c']['dependency']='';
$dictionary['Opportunity']['fields']['sales_territory_c']['visibility_grid']='';

 ?>