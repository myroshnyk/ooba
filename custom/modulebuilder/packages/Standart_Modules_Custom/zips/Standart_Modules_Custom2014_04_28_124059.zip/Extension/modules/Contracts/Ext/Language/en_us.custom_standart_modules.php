<?php 
 // created: 2014-04-26 14:20:32
$mod_strings['LBL_CREATE_BOND_OPPORTUNITY'] = 'Create Bond Opportunity';

?>
