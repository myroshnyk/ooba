<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['product_c']['labelValue']='Product';
$dictionary['Opportunity']['fields']['product_c']['dependency']='';

 ?>