<?php
 // created: 2014-04-28 04:58:06
$dictionary['Lead']['fields']['lead_provider_c']['labelValue']='Lead Provider';
$dictionary['Lead']['fields']['lead_provider_c']['dependency']='';

 ?>