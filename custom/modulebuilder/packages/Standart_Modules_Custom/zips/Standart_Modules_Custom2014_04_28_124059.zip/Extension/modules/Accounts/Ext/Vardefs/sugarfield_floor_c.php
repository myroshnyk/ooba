<?php
 // created: 2014-04-28 04:58:05
$dictionary['Account']['fields']['floor_c']['labelValue']='Floor #';
$dictionary['Account']['fields']['floor_c']['enforced']='';
$dictionary['Account']['fields']['floor_c']['dependency']='';

 ?>