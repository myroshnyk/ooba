<?php
 // created: 2014-04-28 04:58:07
$dictionary['Quote']['fields']['lead_source_c']['labelValue']='Lead Source';
$dictionary['Quote']['fields']['lead_source_c']['dependency']='';
$dictionary['Quote']['fields']['lead_source_c']['visibility_grid']='';

 ?>