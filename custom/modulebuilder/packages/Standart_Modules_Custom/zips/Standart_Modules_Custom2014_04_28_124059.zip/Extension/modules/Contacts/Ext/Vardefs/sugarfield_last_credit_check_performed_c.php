<?php
 // created: 2014-04-28 05:26:01
$dictionary['Contact']['fields']['last_credit_check_performed_c']['labelValue']='Last Credit Check Performed';
$dictionary['Contact']['fields']['last_credit_check_performed_c']['enforced']='';
$dictionary['Contact']['fields']['last_credit_check_performed_c']['dependency']='';

 ?>