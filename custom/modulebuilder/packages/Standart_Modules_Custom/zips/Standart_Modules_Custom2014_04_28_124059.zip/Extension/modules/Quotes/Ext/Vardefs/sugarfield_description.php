<?php
 // created: 2014-04-21 21:38:00
$dictionary['Quote']['fields']['description']['comments']='Full text of the note';
$dictionary['Quote']['fields']['description']['merge_filter']='disabled';
$dictionary['Quote']['fields']['description']['calculated']=false;

 ?>