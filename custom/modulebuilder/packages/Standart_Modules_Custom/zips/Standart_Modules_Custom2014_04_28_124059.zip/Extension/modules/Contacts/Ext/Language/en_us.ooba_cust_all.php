<?php 
 // created: 2014-04-23 12:50:21
$mod_strings['LBL_HOME_PHONE'] = 'Home Phone';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Address Detail - Primary';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Address Detail - Other';
$mod_strings['LBL_PANEL_ADVANCED'] = 'Financial Information';
$mod_strings['LBL_ID_TYPE'] = 'ID Type';
$mod_strings['LBL_ID_NUMBER'] = 'ID Number';
$mod_strings['LBL_GENDER'] = 'Gender';
$mod_strings['LBL_CITIZENSHIP'] = 'Citizenship';
$mod_strings['LBL_MARITAL_STATUS'] = 'Marital Status';
$mod_strings['LBL_OCCUPATION_STATUS'] = 'Occupation Status';
$mod_strings['LBL_SPOUSE_CONTACT_ID'] = 'Spouse (related Contact ID)';
$mod_strings['LBL_SPOUSE'] = 'Spouse';
$mod_strings['LBL_BIRTHDATE'] = 'Date of birth';
$mod_strings['LBL_LENGTH_OF_EMPLOYMENT_Y'] = 'Length of employment (Y)';
$mod_strings['LBL_LENGTH_OF_EMPLOYMENT_M'] = 'Length of employment (M)';
$mod_strings['LBL_BUILDING_COMPLEX_NAME'] = 'Building / Complex Name';
$mod_strings['LBL_UNIT_NUMBER'] = 'Unit Number';
$mod_strings['LBL_STREET_NUMBER'] = 'Street Number';
$mod_strings['LBL_STREET_NAME'] = 'Street Name';
$mod_strings['LBL_FLOOR'] = 'Floor #';
$mod_strings['LBL_SUBURB_POST_OFFICE_RLS01_SUBURBS_ID'] = 'Suburb / post office (related  ID)';
$mod_strings['LBL_SUBURB_POST_OFFICE'] = 'Suburb / post office';
$mod_strings['LBL_PRIMARY_ADDRESS_CITY'] = 'City';
$mod_strings['LBL_PRIMARY_ADDRESS_STATE'] = 'Province';
$mod_strings['LBL_PRIMARY_ADDRESS_POSTALCODE'] = 'Postal Code';
$mod_strings['LBL_PRIMARY_ADDRESS_COUNTRY'] = 'Country';
$mod_strings['LBL_BUILDING_COMPLEX_NAME_2'] = 'Building / Complex Name';
$mod_strings['LBL_UNIT_NUMBER_2'] = 'Unit Number';
$mod_strings['LBL_STREET_NUMBER_2'] = 'Street Number';
$mod_strings['LBL_STREET_NAME_2'] = 'Street Name';
$mod_strings['LBL_FLOOR_2'] = 'Floor #';
$mod_strings['LBL_SUBURB_POST_OFFICE_2_RLS01_SUBURBS_ID'] = 'Suburb / post office (related  ID)';
$mod_strings['LBL_SUBURB_POST_OFFICE_2'] = 'Suburb / post office';
$mod_strings['LBL_COPY_ADDRESS'] = 'Copy address from Primary';
$mod_strings['LBL_ALT_ADDRESS_CITY'] = 'City';
$mod_strings['LBL_ALT_ADDRESS_STATE'] = 'Province';
$mod_strings['LBL_ALT_ADDRESS_POSTALCODE'] = 'Postal Code';
$mod_strings['LBL_ALT_ADDRESS_COUNTRY'] = 'Country';
$mod_strings['LBL_GROSS_INCOME'] = 'Gross Income';
$mod_strings['LBL_EXPENSES'] = 'Expenses';
$mod_strings['LBL_AMOUNT_TO_BE_REPLACED'] = 'Amount to be replaced';
$mod_strings['LBL_MONTHLY_SURETY_COMMITMENT'] = 'Monthly Surety Commitment';
$mod_strings['LBL_NETT_INCOME'] = 'Nett Income';
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';

?>
