<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['unit_number_2_c']['labelValue']='Unit Number';
$dictionary['Contact']['fields']['unit_number_2_c']['enforced']='';
$dictionary['Contact']['fields']['unit_number_2_c']['dependency']='';

 ?>