<?php

	unset($layout_defs['Documents']['subpanel_setup']['cases']);
?>