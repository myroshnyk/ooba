<?php
// created: 2014-04-23 10:20:56
$dictionary["Task"]["fields"]["rls01_agencies_activities_tasks"] = array (
  'name' => 'rls01_agencies_activities_tasks',
  'type' => 'link',
  'relationship' => 'rls01_agencies_activities_tasks',
  'source' => 'non-db',
  'module' => 'rls01_Agencies',
  'bean_name' => false,
  'vname' => 'LBL_RLS01_AGENCIES_ACTIVITIES_TASKS_FROM_RLS01_AGENCIES_TITLE',
);
