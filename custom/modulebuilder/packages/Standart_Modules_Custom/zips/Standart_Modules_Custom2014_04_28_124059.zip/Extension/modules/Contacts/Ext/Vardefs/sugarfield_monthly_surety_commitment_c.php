<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['monthly_surety_commitment_c']['labelValue']='Monthly Surety Commitment';
$dictionary['Contact']['fields']['monthly_surety_commitment_c']['enforced']='';
$dictionary['Contact']['fields']['monthly_surety_commitment_c']['dependency']='';

 ?>