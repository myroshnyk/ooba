<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['spouse_c']['labelValue']='Spouse';
$dictionary['Contact']['fields']['spouse_c']['dependency']='';

 ?>