<?php
 // created: 2014-04-28 04:58:06
$dictionary['Lead']['fields']['lead_status_c']['labelValue']='Status';
$dictionary['Lead']['fields']['lead_status_c']['dependency']='';
$dictionary['Lead']['fields']['lead_status_c']['visibility_grid']='';

 ?>