<?php

//      unset($layout_defs['Contacts']['subpanel_setup']['leads_contacts_1']);
	unset($layout_defs['Contacts']['subpanel_setup']['contacts']);
	unset($layout_defs['Contacts']['subpanel_setup']['cases']);
	unset($layout_defs['Contacts']['subpanel_setup']['campaigns']);
	unset($layout_defs['Contacts']['subpanel_setup']['products']);
?>