<?php
 // created: 2014-04-20 22:12:56
$dictionary['Lead']['fields']['lead_source']['audited']=false;
$dictionary['Lead']['fields']['lead_source']['options']='lead_source_list';
$dictionary['Lead']['fields']['lead_source']['merge_filter']='disabled';
$dictionary['Lead']['fields']['lead_source']['calculated']=false;
$dictionary['Lead']['fields']['lead_source']['dependency']=false;
$dictionary['Lead']['fields']['lead_source']['required']=true;
$dictionary['Lead']['fields']['lead_source']['comments']='Lead source (ex: Web, print)';

 ?>