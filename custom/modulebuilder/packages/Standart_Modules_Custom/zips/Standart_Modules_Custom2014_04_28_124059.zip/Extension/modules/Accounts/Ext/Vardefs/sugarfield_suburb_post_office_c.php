<?php
 // created: 2014-04-28 04:58:05
$dictionary['Account']['fields']['suburb_post_office_c']['labelValue']='Suburb / post office';
$dictionary['Account']['fields']['suburb_post_office_c']['dependency']='';

 ?>