<?php 
 // created: 2014-04-26 14:20:28
$mod_strings['LBL_TYPE'] = 'Type:';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Address Detail - Billing';
$mod_strings['LBL_BUILDING_COMPLEX_NAME'] = 'Building / Complex Name';
$mod_strings['LBL_FLOOR'] = 'Floor #';
$mod_strings['LBL_STREET_NUMBER'] = 'Street Number';
$mod_strings['LBL_SUBURB_POST_OFFICE'] = 'Suburb / post office';
$mod_strings['LBL_UNIT_NUMBER'] = 'Unit Number';
$mod_strings['LBL_STREET_NAME'] = 'Street Name';
$mod_strings['LBL_BILLING_ADDRESS_CITY'] = 'City:';
$mod_strings['LBL_BILLING_ADDRESS_COUNTRY'] = 'Country:';
$mod_strings['LBL_BILLING_ADDRESS_POSTALCODE'] = 'Postal Code:';
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'Province:';

?>
