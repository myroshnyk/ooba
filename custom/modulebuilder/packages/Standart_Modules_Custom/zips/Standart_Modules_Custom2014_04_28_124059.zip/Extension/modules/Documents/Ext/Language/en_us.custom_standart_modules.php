<?php 
 // created: 2014-04-26 14:20:33
$mod_strings['LBL_DOC_STATUS'] = 'Status:';
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';

?>
