<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['gender_c']['labelValue']='Gender';
$dictionary['Contact']['fields']['gender_c']['dependency']='';
$dictionary['Contact']['fields']['gender_c']['visibility_grid']='';

 ?>