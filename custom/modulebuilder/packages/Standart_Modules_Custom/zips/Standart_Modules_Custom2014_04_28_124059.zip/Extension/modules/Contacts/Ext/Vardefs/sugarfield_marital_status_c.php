<?php
 // created: 2014-04-28 05:37:19
$dictionary['Contact']['fields']['marital_status_c']['labelValue']='Marital Status';
$dictionary['Contact']['fields']['marital_status_c']['dependency']='';
$dictionary['Contact']['fields']['marital_status_c']['visibility_grid']='';

 ?>