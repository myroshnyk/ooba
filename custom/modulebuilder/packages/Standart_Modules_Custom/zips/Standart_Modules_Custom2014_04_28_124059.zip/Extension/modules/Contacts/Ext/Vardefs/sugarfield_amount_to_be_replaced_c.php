<?php
 // created: 2014-04-28 04:58:05
$dictionary['Contact']['fields']['amount_to_be_replaced_c']['labelValue']='Amount to be replaced';
$dictionary['Contact']['fields']['amount_to_be_replaced_c']['enforced']='';
$dictionary['Contact']['fields']['amount_to_be_replaced_c']['dependency']='';

 ?>