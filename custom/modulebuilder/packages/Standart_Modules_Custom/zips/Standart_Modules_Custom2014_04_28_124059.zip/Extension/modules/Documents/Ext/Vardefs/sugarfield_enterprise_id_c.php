<?php
 // created: 2014-04-28 04:58:06
$dictionary['Document']['fields']['enterprise_id_c']['labelValue']='enterprise_id';
$dictionary['Document']['fields']['enterprise_id_c']['enforced']='';
$dictionary['Document']['fields']['enterprise_id_c']['dependency']='';

 ?>