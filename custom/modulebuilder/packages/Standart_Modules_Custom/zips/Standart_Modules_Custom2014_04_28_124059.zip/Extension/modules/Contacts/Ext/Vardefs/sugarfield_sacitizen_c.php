<?php
 // created: 2014-04-28 05:23:32
$dictionary['Contact']['fields']['sacitizen_c']['labelValue']='SA Citizen';
$dictionary['Contact']['fields']['sacitizen_c']['enforced']='';
$dictionary['Contact']['fields']['sacitizen_c']['dependency']='';

 ?>