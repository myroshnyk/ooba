<?php
 // created: 2014-04-28 09:42:30
$dictionary['ProductTemplate']['fields']['enterprise_id_c']['labelValue']='ooba Product Code';
$dictionary['ProductTemplate']['fields']['enterprise_id_c']['enforced']='';
$dictionary['ProductTemplate']['fields']['enterprise_id_c']['dependency']='';

 ?>