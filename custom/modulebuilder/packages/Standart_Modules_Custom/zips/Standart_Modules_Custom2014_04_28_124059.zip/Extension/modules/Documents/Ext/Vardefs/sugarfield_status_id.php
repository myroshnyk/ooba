<?php
 // created: 2014-04-23 11:20:30
$dictionary['Document']['fields']['status_id']['options']='doc_status_list';
$dictionary['Document']['fields']['status_id']['merge_filter']='disabled';
$dictionary['Document']['fields']['status_id']['calculated']=false;
$dictionary['Document']['fields']['status_id']['dependency']=false;

 ?>