<?php
 // created: 2014-04-28 04:58:08
$dictionary['Quote']['fields']['sales_territory_c']['labelValue']='Sales Territory';
$dictionary['Quote']['fields']['sales_territory_c']['dependency']='';
$dictionary['Quote']['fields']['sales_territory_c']['visibility_grid']='';

 ?>