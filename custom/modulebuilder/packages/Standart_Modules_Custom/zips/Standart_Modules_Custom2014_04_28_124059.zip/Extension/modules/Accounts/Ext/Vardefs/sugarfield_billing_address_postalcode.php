<?php
 // created: 2014-04-25 18:13:43
$dictionary['Account']['fields']['billing_address_postalcode']['required']=false;
$dictionary['Account']['fields']['billing_address_postalcode']['comments']='The postal code used for billing address';
$dictionary['Account']['fields']['billing_address_postalcode']['merge_filter']='disabled';
$dictionary['Account']['fields']['billing_address_postalcode']['calculated']=false;

 ?>