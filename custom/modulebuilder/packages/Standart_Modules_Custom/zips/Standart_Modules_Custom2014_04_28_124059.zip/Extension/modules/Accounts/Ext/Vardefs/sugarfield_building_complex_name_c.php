<?php
 // created: 2014-04-28 04:58:05
$dictionary['Account']['fields']['building_complex_name_c']['labelValue']='Building / Complex Name';
$dictionary['Account']['fields']['building_complex_name_c']['enforced']='';
$dictionary['Account']['fields']['building_complex_name_c']['dependency']='';

 ?>