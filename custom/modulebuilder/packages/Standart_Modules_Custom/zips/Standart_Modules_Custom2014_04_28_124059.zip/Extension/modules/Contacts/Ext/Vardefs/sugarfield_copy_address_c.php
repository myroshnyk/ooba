<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['copy_address_c']['labelValue']='Copy address from Primary';
$dictionary['Contact']['fields']['copy_address_c']['enforced']='';
$dictionary['Contact']['fields']['copy_address_c']['dependency']='';

 ?>