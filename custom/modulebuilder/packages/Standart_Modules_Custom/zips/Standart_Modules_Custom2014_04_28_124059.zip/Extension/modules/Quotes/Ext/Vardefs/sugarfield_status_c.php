<?php
 // created: 2014-04-28 04:58:08
$dictionary['Quote']['fields']['status_c']['labelValue']='Status';
$dictionary['Quote']['fields']['status_c']['dependency']='';
$dictionary['Quote']['fields']['status_c']['visibility_grid']='';

 ?>