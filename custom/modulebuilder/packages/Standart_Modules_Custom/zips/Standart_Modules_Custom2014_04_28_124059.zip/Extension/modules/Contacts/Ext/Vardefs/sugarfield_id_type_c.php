<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['id_type_c']['labelValue']='ID Type';
$dictionary['Contact']['fields']['id_type_c']['dependency']='';
$dictionary['Contact']['fields']['id_type_c']['visibility_grid']='';

 ?>