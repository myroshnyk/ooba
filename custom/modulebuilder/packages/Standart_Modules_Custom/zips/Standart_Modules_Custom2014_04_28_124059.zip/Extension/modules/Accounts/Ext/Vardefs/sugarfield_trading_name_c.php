<?php
 // created: 2014-04-28 04:58:05
$dictionary['Account']['fields']['trading_name_c']['labelValue']='Trading Name';
$dictionary['Account']['fields']['trading_name_c']['enforced']='';
$dictionary['Account']['fields']['trading_name_c']['dependency']='';

 ?>