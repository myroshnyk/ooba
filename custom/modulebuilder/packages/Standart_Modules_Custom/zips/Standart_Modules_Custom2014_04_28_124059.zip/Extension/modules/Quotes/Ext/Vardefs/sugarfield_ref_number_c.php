<?php
 // created: 2014-04-28 04:58:07
$dictionary['Quote']['fields']['ref_number_c']['labelValue']='Ref Number';
$dictionary['Quote']['fields']['ref_number_c']['enforced']='';
$dictionary['Quote']['fields']['ref_number_c']['dependency']='';

 ?>