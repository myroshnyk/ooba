<?php
 // created: 2014-04-28 04:58:06
$dictionary['Lead']['fields']['lead_provider_agent_c']['labelValue']='Lead Provider (Agent)';
$dictionary['Lead']['fields']['lead_provider_agent_c']['dependency']='';

 ?>