<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['nett_income_c']['labelValue']='Nett Income';
$dictionary['Contact']['fields']['nett_income_c']['enforced']='';
$dictionary['Contact']['fields']['nett_income_c']['dependency']='';

 ?>