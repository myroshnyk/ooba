<?php
 // created: 2014-04-28 04:58:05
$dictionary['Account']['fields']['street_number_c']['labelValue']='Street Number';
$dictionary['Account']['fields']['street_number_c']['enforced']='';
$dictionary['Account']['fields']['street_number_c']['dependency']='';

 ?>