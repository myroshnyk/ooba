<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['floor_c']['labelValue']='Floor #';
$dictionary['Contact']['fields']['floor_c']['enforced']='';
$dictionary['Contact']['fields']['floor_c']['dependency']='';

 ?>