<?php
 // created: 2014-04-28 04:58:06
$dictionary['Lead']['fields']['enterprise_id_c']['labelValue']='enterprise_id';
$dictionary['Lead']['fields']['enterprise_id_c']['enforced']='';
$dictionary['Lead']['fields']['enterprise_id_c']['dependency']='';

 ?>