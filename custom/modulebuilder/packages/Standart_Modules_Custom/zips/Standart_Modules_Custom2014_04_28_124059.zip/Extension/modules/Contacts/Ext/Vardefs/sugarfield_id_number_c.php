<?php
 // created: 2014-04-28 04:58:06
$dictionary['Contact']['fields']['id_number_c']['labelValue']='ID Number';
$dictionary['Contact']['fields']['id_number_c']['enforced']='';
$dictionary['Contact']['fields']['id_number_c']['dependency']='';

 ?>