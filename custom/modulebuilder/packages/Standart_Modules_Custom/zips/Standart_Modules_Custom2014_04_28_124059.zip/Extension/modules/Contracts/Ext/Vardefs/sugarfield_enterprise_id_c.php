<?php
 // created: 2014-04-21 21:57:32
$dictionary['Contract']['fields']['enterprise_id_c']['labelValue']='enterprise_id';
$dictionary['Contract']['fields']['enterprise_id_c']['enforced']='';
$dictionary['Contract']['fields']['enterprise_id_c']['dependency']='';

 ?>