<?php
 // created: 2014-04-16 17:54:56
$dictionary['Contact']['fields']['title']['comments']='The title of the contact';
$dictionary['Contact']['fields']['title']['merge_filter']='disabled';
$dictionary['Contact']['fields']['title']['calculated']=false;

 ?>