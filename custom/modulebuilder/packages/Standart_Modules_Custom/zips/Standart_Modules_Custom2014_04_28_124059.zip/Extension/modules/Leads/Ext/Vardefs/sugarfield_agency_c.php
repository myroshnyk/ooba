<?php
 // created: 2014-04-28 04:58:06
$dictionary['Lead']['fields']['agency_c']['labelValue']='Agency';
$dictionary['Lead']['fields']['agency_c']['dependency']='';

 ?>