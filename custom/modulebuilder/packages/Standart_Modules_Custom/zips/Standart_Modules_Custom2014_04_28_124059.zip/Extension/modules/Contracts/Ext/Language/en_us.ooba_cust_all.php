<?php 
 // created: 2014-04-23 12:50:24
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';

?>
