<?php
 // created: 2014-04-28 04:58:07
$dictionary['Quote']['fields']['refferer_c']['labelValue']='Refferer';
$dictionary['Quote']['fields']['refferer_c']['dependency']='';

 ?>