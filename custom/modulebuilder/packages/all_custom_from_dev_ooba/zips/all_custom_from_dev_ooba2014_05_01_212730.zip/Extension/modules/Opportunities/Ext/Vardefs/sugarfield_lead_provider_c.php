<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['lead_provider_c']['labelValue']='Lead Provider';
$dictionary['Opportunity']['fields']['lead_provider_c']['dependency']='';

 ?>