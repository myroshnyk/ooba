<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['sales_territory_c']['labelValue']='Sales Territory';
$dictionary['Opportunity']['fields']['sales_territory_c']['dependency']='';
$dictionary['Opportunity']['fields']['sales_territory_c']['visibility_grid']='';

 ?>