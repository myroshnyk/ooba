<?php
// created: 2014-04-26 06:47:20
$dictionary["rls01_RealEstatebranches"]["fields"]["rls01_branches_activities_notes"] = array (
  'name' => 'rls01_branches_activities_notes',
  'type' => 'link',
  'relationship' => 'rls01_branches_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_RLS01_AGENTS_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
