<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['communication_representative_c']['labelValue']=' ooba Representative';
$dictionary['Opportunity']['fields']['communication_representative_c']['dependency']='';

 ?>