<?php
 // created: 2014-05-01 20:50:15
$dictionary['Lead']['fields']['phone_type_c']['labelValue']='Phone Type';
$dictionary['Lead']['fields']['phone_type_c']['dependency']='';
$dictionary['Lead']['fields']['phone_type_c']['visibility_grid']='';

 ?>