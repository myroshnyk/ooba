<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['agency_c']['labelValue']='Agency';
$dictionary['Opportunity']['fields']['agency_c']['dependency']='';

 ?>