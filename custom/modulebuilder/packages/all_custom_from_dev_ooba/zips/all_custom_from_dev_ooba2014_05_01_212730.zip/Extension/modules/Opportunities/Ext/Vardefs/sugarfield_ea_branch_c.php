<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['ea_branch_c']['labelValue']='EA Branch';
$dictionary['Opportunity']['fields']['ea_branch_c']['dependency']='';

 ?>