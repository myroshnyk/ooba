<?php
 // created: 2014-05-01 21:06:42
$dictionary['Opportunity']['fields']['lost_reason_c']['labelValue']='Lost Reason';
$dictionary['Opportunity']['fields']['lost_reason_c']['dependency']='';
$dictionary['Opportunity']['fields']['lost_reason_c']['visibility_grid']='';

 ?>