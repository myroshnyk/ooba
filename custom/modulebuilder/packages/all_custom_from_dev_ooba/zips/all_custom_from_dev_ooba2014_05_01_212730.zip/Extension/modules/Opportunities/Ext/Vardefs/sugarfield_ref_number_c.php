<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['ref_number_c']['labelValue']='Ref Number';
$dictionary['Opportunity']['fields']['ref_number_c']['enforced']='';
$dictionary['Opportunity']['fields']['ref_number_c']['dependency']='';

 ?>