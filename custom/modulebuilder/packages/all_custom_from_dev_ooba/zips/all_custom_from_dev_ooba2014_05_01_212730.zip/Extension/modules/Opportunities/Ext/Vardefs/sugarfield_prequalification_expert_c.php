<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['prequalification_expert_c']['labelValue']='Prequalification Expert';
$dictionary['Opportunity']['fields']['prequalification_expert_c']['dependency']='';

 ?>