<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['sales_consultant_c']['labelValue']='Prequalification Expert';
$dictionary['Opportunity']['fields']['sales_consultant_c']['dependency']='';

 ?>