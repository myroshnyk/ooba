<?php 
 // created: 2014-04-26 14:20:36
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Overview';
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';
$mod_strings['LBL_PRIMARY_LEAD_LEAD_ID'] = 'Primary Lead (related Lead ID)';
$mod_strings['LBL_PRIMARY_LEAD'] = 'Primary Lead';

?>
