<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['refferer_c']['labelValue']='Refferer';
$dictionary['Opportunity']['fields']['refferer_c']['dependency']='';

 ?>