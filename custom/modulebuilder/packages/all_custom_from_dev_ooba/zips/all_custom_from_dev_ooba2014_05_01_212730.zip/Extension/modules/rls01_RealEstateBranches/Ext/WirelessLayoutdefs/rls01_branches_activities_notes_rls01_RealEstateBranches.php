<?php
 // created: 2014-04-26 06:47:20
$layout_defs["rls01_RealEstateBranches"]["subpanel_setup"]['rls01_branches_activities_notes'] = array (
  'order' => 100,
  'module' => 'Notes',
  'subpanel_name' => 'Default',
  'title_key' => 'LBL_RLS01_AGENCIES_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
  'get_subpanel_data' => 'rls01_branches_activities_notes',
);
