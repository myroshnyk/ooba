<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['enterprise_id_c']['labelValue']='enterprise_id';
$dictionary['Opportunity']['fields']['enterprise_id_c']['enforced']='';
$dictionary['Opportunity']['fields']['enterprise_id_c']['dependency']='';

 ?>