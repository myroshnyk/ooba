<?php
 // created: 2014-05-01 18:54:40
$dictionary['Opportunity']['fields']['status_c']['labelValue']='Status';
$dictionary['Opportunity']['fields']['status_c']['dependency']='';
$dictionary['Opportunity']['fields']['status_c']['visibility_grid']='';

 ?>