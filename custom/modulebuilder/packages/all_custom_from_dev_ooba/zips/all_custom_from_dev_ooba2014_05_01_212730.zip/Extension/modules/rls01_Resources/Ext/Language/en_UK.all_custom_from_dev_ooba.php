<?php 
 // created: 2014-05-01 09:54:56
$mod_strings['LBL_ENTERPRISE_ID'] = 'Resource Number';
$mod_strings['LBL_USER_REL_USER_ID'] = 'User Relationship (related User ID)';
$mod_strings['LBL_USER_REL'] = 'User Relationship';
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Overview';
$mod_strings['LBL_ACTIVE'] = 'Active';
$mod_strings['LBL_DESCRIPTION'] = 'Notes';
$mod_strings['LBL_MOBILE_PHONE'] = 'Mobile';

?>
