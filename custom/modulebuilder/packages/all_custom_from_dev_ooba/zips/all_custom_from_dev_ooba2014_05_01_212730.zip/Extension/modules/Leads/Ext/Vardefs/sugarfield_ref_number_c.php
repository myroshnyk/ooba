<?php
 // created: 2014-05-01 13:00:28
$dictionary['Lead']['fields']['ref_number_c']['labelValue']='Ref Number';
$dictionary['Lead']['fields']['ref_number_c']['enforced']='';
$dictionary['Lead']['fields']['ref_number_c']['dependency']='';

 ?>