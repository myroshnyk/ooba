<?php
 // created: 2014-05-01 13:00:30
$dictionary['rls01_RealEstateBranches']['fields']['account_manager_kam_c']['labelValue']='Account Manager (KAM)';
$dictionary['rls01_RealEstateBranches']['fields']['account_manager_kam_c']['dependency']='';

 ?>