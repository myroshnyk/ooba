<?php
 // created: 2014-05-01 13:00:30
$dictionary['rls01_Resources']['fields']['active_c']['labelValue']='Active';
$dictionary['rls01_Resources']['fields']['active_c']['enforced']='';
$dictionary['rls01_Resources']['fields']['active_c']['dependency']='';

 ?>