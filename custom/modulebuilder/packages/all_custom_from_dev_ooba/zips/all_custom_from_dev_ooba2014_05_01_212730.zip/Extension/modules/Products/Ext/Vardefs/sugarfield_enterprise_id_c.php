<?php
 // created: 2014-05-01 13:00:29
$dictionary['Product']['fields']['enterprise_id_c']['labelValue']='ooba Product Code';
$dictionary['Product']['fields']['enterprise_id_c']['enforced']='';
$dictionary['Product']['fields']['enterprise_id_c']['dependency']='';

 ?>