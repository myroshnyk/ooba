<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['primary_lead_c']['labelValue']='Primary Lead';
$dictionary['Opportunity']['fields']['primary_lead_c']['dependency']='';

 ?>