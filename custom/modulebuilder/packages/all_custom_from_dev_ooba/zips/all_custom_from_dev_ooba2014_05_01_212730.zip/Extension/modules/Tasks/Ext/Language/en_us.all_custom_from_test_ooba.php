<?php 
 // created: 2014-04-30 11:28:25
$mod_strings['LBL_RLS01_PARTNERSHIPS_ACTIVITIES_TASKS_FROM_RLS01_REALESTATEPARTNERSHIPS_TITLE'] = 'Activities:Real Estate Real Estate Partnerships';

?>
