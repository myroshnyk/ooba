<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['communication_prospectprimar_c']['labelValue']='Communication Prospect';
$dictionary['Opportunity']['fields']['communication_prospectprimar_c']['dependency']='';

 ?>