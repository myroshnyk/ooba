<?php
 // created: 2014-05-01 13:00:29
$dictionary['Opportunity']['fields']['product_c']['labelValue']='Product Category';
$dictionary['Opportunity']['fields']['product_c']['enforced']='';
$dictionary['Opportunity']['fields']['product_c']['dependency']='';

 ?>