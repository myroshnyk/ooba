<?php
// created: 2014-04-26 06:47:20
$dictionary["rls01_RealEstateAgencies"]["fields"]["rls01_agencies_activities_meetings"] = array (
  'name' => 'rls01_agencies_activities_meetings',
  'type' => 'link',
  'relationship' => 'rls01_agencies_activities_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_RLS01_AGENCIES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
