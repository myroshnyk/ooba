<?php 
 // created: 2014-05-01 21:27:14
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Overview';
$mod_strings['LBL_LEAD_PROVIDER_WEB'] = 'Lead Provider (Web Entity)';
$mod_strings['LBL_ID_TYPE'] = 'ID Type';
$mod_strings['LBL_STAGE'] = 'Stage';
$mod_strings['LBL_STATUS'] = 'Status_original:';
$mod_strings['LBL_LEAD_STATUS'] = 'Status';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Source:';
$mod_strings['LBL_PHONE_TYPE'] = 'Phone Type';

?>
