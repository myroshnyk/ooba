<?php 
 // created: 2014-05-01 21:27:16
$mod_strings['LBL_ENTERPRISE_ID'] = 'ooba Product Code';

?>
