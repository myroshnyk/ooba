<?php
$listViewDefs ['ProductTemplates'] = 
array (
  'CATEGORY_NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_CATEGORY',
    'link' => false,
    'sortable' => true,
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '30%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
  ),
  'STATUS' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_STATUS',
    'link' => false,
    'default' => true,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'ENTERPRISE_ID_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_ENTERPRISE_ID',
    'width' => '10%',
  ),
);
?>
