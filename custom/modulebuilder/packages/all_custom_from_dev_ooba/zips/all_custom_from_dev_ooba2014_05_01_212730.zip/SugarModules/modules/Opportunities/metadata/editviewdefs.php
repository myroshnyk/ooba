<?php
$viewdefs ['Opportunities'] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'javascript' => '{$PROBABILITY_SCRIPT}',
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_PANEL_ASSIGNMENT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
          ),
          1 => 'account_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'product_c',
            'studio' => 'visible',
            'label' => 'LBL_PRODUCT',
            'customCode' =>'<select id="product_c" name="product_c">{$PRODCAT}</select>' 
          ),
          1 => 
          array (
            'name' => 'ref_number_c',
            'label' => 'LBL_REF_NUMBER',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'status_c',
            'studio' => 'visible',
            'label' => 'LBL_STATUS',
          ),
          1 => 'opportunity_type',
        ),
        3 => 
        array (
          0 => 'sales_stage',
          1 => 'probability',
        ),
        4 => 
        array (
          0 => 'lead_source',
          1 => 
          array (
            'name' => 'lead_provider_c',
            'studio' => 'visible',
            'label' => 'LBL_LEAD_PROVIDER',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'agency_c',
            'studio' => 'visible',
            'label' => 'LBL_AGENCY',
          ),
          1 => 
          array (
            'name' => 'ea_branch_c',
            'studio' => 'visible',
            'label' => 'LBL_EA_BRANCH',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'refferer_c',
            'studio' => 'visible',
            'label' => 'LBL_REFFERER',
          ),
          1 => 
          array (
            'name' => 'prequalification_expert_c',
            'studio' => 'visible',
            'label' => 'LBL_PREQUALIFICATION_EXPERT',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'sales_territory_c',
            'studio' => 'visible',
            'label' => 'LBL_SALES_TERRITORY',
          ),
          1 => 
          array (
            'name' => 'amount',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'lost_reason_c',
            'studio' => 'visible',
            'label' => 'LBL_LOST_REASON',
          ),
          1 => 
          array (
            'name' => 'primary_lead_c',
            'studio' => 'visible',
            'label' => 'LBL_PRIMARY_LEAD',
          ),
        ),
      ),
      'LBL_PANEL_ASSIGNMENT' => 
      array (
        0 => 
        array (
          0 => 'campaign_name',
          1 => 'description',
        ),
        1 => 
        array (
          0 => 'assigned_user_name',
          1 => 
          array (
            'name' => 'team_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
          1 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
        ),
        3 => 
        array (
          0 => '',
          1 => 
          array (
            'name' => 'enterprise_id_c',
            'label' => 'LBL_ENTERPRISE_ID',
          ),
        ),
      ),
    ),
  ),
);
?>
