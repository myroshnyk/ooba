<?php 
 // created: 2014-05-01 21:27:13
$mod_strings['LBL_CONTRACT_INFORMATION'] = 'Overview';

?>
