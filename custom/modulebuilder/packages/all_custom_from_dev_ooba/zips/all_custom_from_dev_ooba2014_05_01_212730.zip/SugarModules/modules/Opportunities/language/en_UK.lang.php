<?php 
 // created: 2014-05-01 21:27:16
$mod_strings['LBL_AMOUNT'] = 'Desired Amount';
$mod_strings['LBL_DESCRIPTION'] = 'Comments';
$mod_strings['LBL_COMMUNICATION_PROSPECTPRIMAR_CONTACT_ID'] = 'Communication ProspectPrimary Lead (related Contact ID)';
$mod_strings['LBL_COMMUNICATION_PROSPECTPRIMAR'] = 'Communication Prospect';
$mod_strings['LBL_PRODUCT'] = 'Product Category';
$mod_strings['LBL_LIST_AMOUNT_USDOLLAR'] = 'Desired Amount';
$mod_strings['LBL_STATUS'] = 'Status';
$mod_strings['LBL_TYPE'] = 'Type:';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Source:';
$mod_strings['LBL_LOST_REASON'] = 'Lost Reason';

?>
