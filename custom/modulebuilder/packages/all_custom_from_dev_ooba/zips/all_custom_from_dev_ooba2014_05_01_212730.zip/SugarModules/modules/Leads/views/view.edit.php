<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (“MSA”), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/

require_once('modules/Leads/views/view.edit.php');
class CustomLeadsViewEdit extends LeadsViewEdit
{
  /**
  * @see SugarView::preDisplay()
  */
  public function preDisplay()
  { 		
    parent::preDisplay();            
  }
  
  /**
  * @see SugarView::display()
  */
  
  function display() {
    global $mod_strings;
  
    $javascript = <<<EOQ
      <script language='javascript'>
      $(function() {
                  
        $.mask.definitions['~'] = "[+-]";                          // Setup masked phone number input
        $("#phone_work").mask("(999) 999-9999");

        $("input").blur(function() {
          $("#info").html("Unmasked value: " + $(this).mask());
        }).dblclick(function() {
          $(this).unmask();
        });
  
 
 
        $('#lead_source').change(function () {
        
          var lead_source = $(this).val();
          if (lead_source == '6') {                           // Real Estate - Agency and EA Branch required                
            $('#agency_c').show().siblings().show(); 
            $('#agency_c_label').html ('{$mod_strings['LBL_AGENCY']}: <span class="required">*</span>');      
            addToValidate ('EditView', 'agency_c', 'varchar', true, '{$mod_strings['LBL_AGENCY']}');        
            
            $('#ea_branch_c').show().siblings().show(); 
            $('#ea_branch_c_label').html ('{$mod_strings['LBL_EA_BRANCH']}: <span class="required">*</span>');  
            addToValidate ('EditView', 'ea_branch_c', 'varchar', true, '{$mod_strings['LBL_EA_BRANCH']}'); 
          }          
          else {                                              // Other sources -  Agency and EA Branch hided
            $('#agency_c').hide().siblings().hide();              
            $('#agency_c_label').html ('');                              
            removeFromValidate('EditView','agency_c');                      
            
            $('#ea_branch_c').hide().siblings().hide();
            $('#ea_branch_c_label').html ('');  
            removeFromValidate('EditView','ea_branch_c');             
          }
          
          
          $('#lead_provider_agent_c').hide().siblings().hide();
          $('#lead_provider_agent_c_label').html('');
          removeFromValidate('EditView','lead_provider_agent_c'); 
          
          $('#lead_provider_c').hide().siblings().hide();
          $('#lead_provider_c_label').html('');  
          removeFromValidate('EditView','lead_provider_c');            
          
          $('#lead_provider_resource_c').hide().siblings().hide();
          $('#lead_provider_resource_c_label').html('');
          removeFromValidate('EditView','lead_provider_resource_c');   
          
          $('#lead_provider_web_c').hide().siblings().hide();
          $('#lead_provider_web_c_label').html('');
          removeFromValidate('EditView','lead_provider_web_c');   
          
                              
          switch (lead_source) {
            case '6':                                                    // Real Estate: Lead Provider -> Agent
              $('#lead_provider_agent_c').show().siblings().show();          
              $('#lead_provider_agent_c_label').html ('{$mod_strings['LBL_LEAD_PROVIDER_AGENT']}: <span class="required">*</span>');    
              addToValidate ('EditView', 'lead_provider_agent_c', 'varchar', true, '{$mod_strings['LBL_LEAD_PROVIDER_AGENT']}');   
            break;
            
            case '7':                                                    // Staff: Lead Provider -> Resource
              $('#lead_provider_resource_c').show().siblings().show(); 
              $('#lead_provider_resource_c_label').html ('{$mod_strings['LBL_LEAD_PROVIDER_RESOURCE']}: <span class="required">*</span>');   
              addToValidate ('EditView', 'lead_provider_resource_c', 'varchar', true, '{$mod_strings['LBL_LEAD_PROVIDER_RESOURCE']}'); 
            break;
            
            case '4':                                                    // Web site: Lead Provider -> Web Entity
              $('#lead_provider_web_c').show().siblings().show(); 
              $('#lead_provider_web_c_label').html ('{$mod_strings['LBL_LEAD_PROVIDER_WEB']}: <span class="required">*</span>');   
              addToValidate ('EditView', 'lead_provider_web_c', 'varchar', true, '{$mod_strings['LBL_LEAD_PROVIDER_WEB']}'); 
            break;
                                                
            default:                                                     // Other: Lead Provider -> Contact
              $('#lead_provider_c').show().siblings().show(); 
              $('#lead_provider_c_label').html ('{$mod_strings['LBL_LEAD_PROVIDER']}: <span class="required">*</span>');     
              addToValidate ('EditView', 'lead_provider_c', 'varchar', true, '{$mod_strings['LBL_LEAD_PROVIDER']}'); 
            break;
          }      
        });
        
       
/*       
        $('#btn_lead_provider_agent_c').removeAttr('onclick');               // Agents filtered by Branch
        $('#btn_lead_provider_agent_c').on('click',(function() {            
          var branch = $('#ea_branch_c').val();
          var initialfilter="&rls01_agencies_rls01_branches_name_advanced=" + branch;
        
          open_popup ("rls01_RealEstateBranches", 600, 400, initialfilter, true, false, {
            "call_back_function": "set_return",
            "form_name": "EditView",
            "field_to_name_array": {
              "id": "rls01_realestatebranches_id_c",
              "name": "ea_branch_c",
              "rls01_agencies_rls01_branchesrls01_realestateagencies_ida": "rls01_realestateagencies_id_c",
              "rls01_agencies_rls01_branches_name": "agency_c",   
            }
          }, "single", true);
        }));
*/       
       
               
        $('#btn_ea_branch_c').removeAttr('onclick');               // EA Branch filtered by Agency
        $('#btn_ea_branch_c').on('click',(function() {            
          var agency = $('#agency_c').val();
          var initialfilter="&rls01_agencies_rls01_branches_name_advanced=" + agency;
        
          open_popup ("rls01_RealEstateBranches", 600, 400, initialfilter, true, false, {
            "call_back_function": "set_return",
            "form_name": "EditView",
            "field_to_name_array": {
              "id": "rls01_realestatebranches_id_c",
              "name": "ea_branch_c",
              "rls01_agencies_rls01_branchesrls01_realestateagencies_ida": "rls01_realestateagencies_id_c",
              "rls01_agencies_rls01_branches_name": "agency_c",   
            }
          }, "single", true);
        }));
   

      $('#lead_source').change();                                  // Upload initialization
      
                                                            
    });
    </script>
EOQ;

      //parent::display();
      $category = new ProductCategory();
           $opt= get_select_options_with_id($category->get_product_categories(true), $this->bean->product_c);
           $this->ev->process();
           $this->ev->ss->assign('PRODCAT',$opt);
           
          if($this->ev->isDuplicate) { 
           foreach($this->ev->fieldDefs as $name=>$defs) { 
                   if(!empty($defs['auto_increment'])) { 
                      $this->ev->fieldDefs[$name]['value'] = ''; 
                   } 
           } 
        } 
      echo $this->ev->display();  //display rest normally
      echo $javascript; 
  }
}
