<?php 
 // created: 2014-05-01 21:27:10
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'Province:';

?>
