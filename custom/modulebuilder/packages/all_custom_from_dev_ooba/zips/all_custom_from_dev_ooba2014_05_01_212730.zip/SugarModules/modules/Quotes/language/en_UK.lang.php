<?php 
 // created: 2014-05-01 21:27:17
$mod_strings['LBL_QUOTE_INFORMATION'] = 'Overview';

?>
