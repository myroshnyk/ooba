<?php 
 // created: 2014-05-01 21:27:22
$mod_strings['LNK_NEW_RECORD'] = 'Create Real Estate Real Estate Partnerships';
$mod_strings['LNK_LIST'] = 'View Real Estate Real Estate Partnerships';
$mod_strings['LNK_IMPORT_RLS01_REALESTATEPARTNERSHIPS'] = 'Import Real Estate Real Estate Partnerships';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Real Estate Partnerships List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Real Estate Partnerships';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Real Estate Real Estate Partnerships';

?>
