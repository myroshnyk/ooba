<?php 
 // created: 2014-05-01 09:54:45
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'Province:';

?>
