<?php 
 // created: 2014-05-01 09:54:56
$mod_strings['LBL_SUBURB_NO'] = 'Suburb No_int_to_delete';

?>
