<?php 
 // created: 2014-05-01 09:54:47
$mod_strings['LBL_CONTRACT_INFORMATION'] = 'Overview';

?>
