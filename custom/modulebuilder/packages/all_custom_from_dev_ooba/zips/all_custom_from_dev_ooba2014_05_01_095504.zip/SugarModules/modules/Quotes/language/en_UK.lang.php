<?php 
 // created: 2014-05-01 09:54:52
$mod_strings['LBL_QUOTE_INFORMATION'] = 'Overview';

?>
