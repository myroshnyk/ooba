<?php 
 // created: 2014-05-01 09:54:50
$mod_strings['LBL_AMOUNT'] = 'Desired Amount';
$mod_strings['LBL_DESCRIPTION'] = 'Comments';
$mod_strings['LBL_COMMUNICATION_PROSPECTPRIMAR_CONTACT_ID'] = 'Communication ProspectPrimary Lead (related Contact ID)';
$mod_strings['LBL_COMMUNICATION_PROSPECTPRIMAR'] = 'Communication Prospect';
$mod_strings['LBL_PRODUCT'] = 'Product Category';
$mod_strings['LBL_LIST_AMOUNT_USDOLLAR'] = 'Desired Amount';

?>
