<?php 
 // created: 2014-05-01 09:54:46
$mod_strings['LBL_SACITIZEN'] = 'SA Citizen';
$mod_strings['LBL_LAST_CREDIT_CHECK_PERFORMED'] = 'Last Credit Check Performed';

?>
