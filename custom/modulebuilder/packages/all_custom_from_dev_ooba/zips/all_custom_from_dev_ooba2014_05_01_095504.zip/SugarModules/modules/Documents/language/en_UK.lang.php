<?php 
 // created: 2014-05-01 09:54:48
$mod_strings['LBL_DOCUMENT_INFORMATION'] = 'Overview';
$mod_strings['LBL_DET_IS_TEMPLATE'] = 'Template';

?>
