<?php 
 // created: 2014-04-26 14:20:37
$mod_strings['LBL_LIST_PRICE'] = 'Value:';
$mod_strings[1] = 'Other';

?>
