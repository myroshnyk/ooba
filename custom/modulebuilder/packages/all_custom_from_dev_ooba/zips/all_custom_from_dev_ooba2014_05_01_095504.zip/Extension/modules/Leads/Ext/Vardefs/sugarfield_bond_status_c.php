<?php
 // created: 2014-04-30 12:09:51
$dictionary['Lead']['fields']['bond_status_c']['labelValue']='Bond Status';
$dictionary['Lead']['fields']['bond_status_c']['enforced']='';
$dictionary['Lead']['fields']['bond_status_c']['dependency']='';

 ?>