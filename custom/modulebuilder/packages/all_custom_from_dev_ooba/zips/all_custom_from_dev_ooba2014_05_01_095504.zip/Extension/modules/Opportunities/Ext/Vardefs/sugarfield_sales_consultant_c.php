<?php
 // created: 2014-04-30 12:09:52
$dictionary['Opportunity']['fields']['sales_consultant_c']['labelValue']='Prequalification Expert';
$dictionary['Opportunity']['fields']['sales_consultant_c']['dependency']='';

 ?>