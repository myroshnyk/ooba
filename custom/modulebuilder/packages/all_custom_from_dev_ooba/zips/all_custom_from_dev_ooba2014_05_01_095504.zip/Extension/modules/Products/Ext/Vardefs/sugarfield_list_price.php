<?php
 // created: 2014-05-01 01:23:16
$dictionary['Product']['fields']['list_price']['comments']='List price of product ("List" in Quote)';
$dictionary['Product']['fields']['list_price']['merge_filter']='disabled';
$dictionary['Product']['fields']['list_price']['calculated']=false;
$dictionary['Product']['fields']['list_price']['enable_range_search']=false;

 ?>