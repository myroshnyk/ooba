<?php
 // created: 2014-04-28 01:07:03
$layout_defs["rls01_RealEstateAgents"]["subpanel_setup"]['rls01_realestateagents_rls01_realestatepartnerships_2'] = array (
  'order' => 100,
  'module' => 'rls01_RealEstatePartnerships',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_RLS01_REALESTATEAGENTS_RLS01_REALESTATEPARTNERSHIPS_2_FROM_RLS01_REALESTATEPARTNERSHIPS_TITLE',
  'get_subpanel_data' => 'rls01_realestateagents_rls01_realestatepartnerships_2',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
