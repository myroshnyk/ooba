<?php
 // created: 2014-04-28 01:04:48
$layout_defs["rls01_RealEstateBranches"]["subpanel_setup"]['rls01_realestatebranches_rls01_realestatepartnerships_2'] = array (
  'order' => 100,
  'module' => 'rls01_RealEstatePartnerships',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_RLS01_REALESTATEBRANCHES_RLS01_REALESTATEPARTNERSHIPS_2_FROM_RLS01_REALESTATEPARTNERSHIPS_TITLE',
  'get_subpanel_data' => 'rls01_realestatebranches_rls01_realestatepartnerships_2',
);
