<?php
// created: 2014-04-26 06:47:20
$dictionary["rls01_RealEstateAgencies"]["fields"]["rls01_agencies_activities_calls"] = array (
  'name' => 'rls01_agencies_activities_calls',
  'type' => 'link',
  'relationship' => 'rls01_agencies_activities_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_RLS01_AGENCIES_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
