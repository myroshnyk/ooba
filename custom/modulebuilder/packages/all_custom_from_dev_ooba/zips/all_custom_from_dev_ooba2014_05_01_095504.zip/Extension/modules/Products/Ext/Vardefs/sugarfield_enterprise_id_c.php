<?php
 // created: 2014-04-30 18:16:50
$dictionary['Product']['fields']['enterprise_id_c']['labelValue']='ooba Product Code';
$dictionary['Product']['fields']['enterprise_id_c']['enforced']='';
$dictionary['Product']['fields']['enterprise_id_c']['dependency']='';

 ?>