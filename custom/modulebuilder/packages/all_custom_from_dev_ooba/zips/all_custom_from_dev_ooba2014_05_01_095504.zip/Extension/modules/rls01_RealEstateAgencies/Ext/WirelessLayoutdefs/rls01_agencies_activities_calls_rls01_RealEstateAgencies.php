<?php
 // created: 2014-04-26 06:47:20
$layout_defs["rls01_RealEstateAgencies"]["subpanel_setup"]['rls01_agencies_activities_calls'] = array (
  'order' => 100,
  'module' => 'Calls',
  'subpanel_name' => 'Default',
  'title_key' => 'LBL_RLS01_AGENCIES_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
  'get_subpanel_data' => 'rls01_agencies_activities_calls',
);
