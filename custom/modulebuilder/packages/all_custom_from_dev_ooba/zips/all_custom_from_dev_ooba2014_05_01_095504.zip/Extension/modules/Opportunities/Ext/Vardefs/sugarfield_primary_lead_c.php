<?php
 // created: 2014-04-30 12:09:52
$dictionary['Opportunity']['fields']['primary_lead_c']['labelValue']='Primary Lead';
$dictionary['Opportunity']['fields']['primary_lead_c']['dependency']='';

 ?>