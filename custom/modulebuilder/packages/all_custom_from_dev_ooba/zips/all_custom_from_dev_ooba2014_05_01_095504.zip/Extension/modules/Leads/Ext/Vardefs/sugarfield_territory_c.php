<?php
 // created: 2014-04-30 12:09:51
$dictionary['Lead']['fields']['territory_c']['labelValue']='Sales Territory';
$dictionary['Lead']['fields']['territory_c']['dependency']='';
$dictionary['Lead']['fields']['territory_c']['visibility_grid']='';

 ?>