<?php
 // created: 2014-05-01 00:59:17
$dictionary['rls01_Resources']['fields']['phone_mobile']['full_text_search']=array (
);

 ?>