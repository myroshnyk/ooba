<?php
 // created: 2014-04-30 17:49:56
$dictionary['rls01_Resources']['fields']['active_c']['labelValue']='Active';
$dictionary['rls01_Resources']['fields']['active_c']['enforced']='';
$dictionary['rls01_Resources']['fields']['active_c']['dependency']='';

 ?>