<?php
// created: 2014-04-25 15:05:05
$dictionary["Task"]["fields"]["rls01_agents_activities_tasks"] = array (
  'name' => 'rls01_agents_activities_tasks',
  'type' => 'link',
  'relationship' => 'rls01_agents_activities_tasks',
  'source' => 'non-db',
  'module' => 'rls01_Agents',
  'bean_name' => false,
  'vname' => 'LBL_RLS01_AGENTS_ACTIVITIES_TASKS_FROM_RLS01_AGENTS_TITLE',
);
