<?php
 // created: 2014-04-28 17:29:09
$layout_defs["Contacts"]["subpanel_setup"]['contacts_quotes_1'] = array (
  'order' => 100,
  'module' => 'Quotes',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTACTS_QUOTES_1_FROM_QUOTES_TITLE',
  'get_subpanel_data' => 'contacts_quotes_1',
);
