<?php 
 // created: 2014-04-30 11:28:28
$mod_strings['LBL_ENTERPRISE_ID'] = 'Resource Number';

?>
