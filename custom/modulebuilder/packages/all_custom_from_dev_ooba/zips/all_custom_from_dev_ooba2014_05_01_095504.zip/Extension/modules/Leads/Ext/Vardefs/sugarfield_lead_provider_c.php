<?php
 // created: 2014-04-30 12:09:51
$dictionary['Lead']['fields']['lead_provider_c']['labelValue']='Lead Provider';
$dictionary['Lead']['fields']['lead_provider_c']['dependency']='';

 ?>