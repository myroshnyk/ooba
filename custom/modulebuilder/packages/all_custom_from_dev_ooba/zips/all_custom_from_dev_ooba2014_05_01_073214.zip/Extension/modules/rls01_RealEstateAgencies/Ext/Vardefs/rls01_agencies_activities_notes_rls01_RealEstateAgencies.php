<?php
// created: 2014-04-26 06:47:20
$dictionary["rls01_RealEstateAgencies"]["fields"]["rls01_agencies_activities_notes"] = array (
  'name' => 'rls01_agencies_activities_notes',
  'type' => 'link',
  'relationship' => 'rls01_agencies_activities_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_RLS01_AGENCIES_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
