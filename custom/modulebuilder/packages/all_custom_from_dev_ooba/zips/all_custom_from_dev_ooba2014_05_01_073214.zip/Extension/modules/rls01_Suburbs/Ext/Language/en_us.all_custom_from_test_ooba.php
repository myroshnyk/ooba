<?php 
 // created: 2014-04-30 11:28:29
$mod_strings['LBL_SUBURB_NO'] = 'Suburb No b';
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';

?>
