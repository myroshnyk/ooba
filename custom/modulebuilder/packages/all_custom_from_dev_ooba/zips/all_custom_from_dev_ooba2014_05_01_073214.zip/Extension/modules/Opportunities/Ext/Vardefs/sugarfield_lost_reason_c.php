<?php
 // created: 2014-04-30 12:09:52
$dictionary['Opportunity']['fields']['lost_reason_c']['labelValue']='Lost Reason';
$dictionary['Opportunity']['fields']['lost_reason_c']['dependency']='';
$dictionary['Opportunity']['fields']['lost_reason_c']['visibility_grid']='';

 ?>