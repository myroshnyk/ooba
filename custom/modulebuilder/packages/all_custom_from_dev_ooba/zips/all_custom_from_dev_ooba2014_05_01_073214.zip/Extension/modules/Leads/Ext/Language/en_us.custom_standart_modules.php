<?php 
 // created: 2014-04-26 14:20:34
$mod_strings['LBL_FINDE_DUPLICATE'] = 'Finde Duplicate';
$mod_strings['LBL_FINDE_CANCEL'] = 'Cancel';

?>
