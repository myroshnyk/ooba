<?php
// created: 2014-04-28 17:29:09
$dictionary["Contact"]["fields"]["contacts_quotes_1"] = array (
  'name' => 'contacts_quotes_1',
  'type' => 'link',
  'relationship' => 'contacts_quotes_1',
  'source' => 'non-db',
  'module' => 'Quotes',
  'bean_name' => 'Quote',
  'vname' => 'LBL_CONTACTS_QUOTES_1_FROM_QUOTES_TITLE',
);
