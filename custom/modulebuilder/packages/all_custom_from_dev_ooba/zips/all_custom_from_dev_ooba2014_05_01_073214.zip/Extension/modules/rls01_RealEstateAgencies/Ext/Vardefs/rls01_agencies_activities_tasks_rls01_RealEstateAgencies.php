<?php
// created: 2014-04-26 06:47:20
$dictionary["rls01_RealEstateAgencies"]["fields"]["rls01_agencies_activities_tasks"] = array (
  'name' => 'rls01_agencies_activities_tasks',
  'type' => 'link',
  'relationship' => 'rls01_agencies_activities_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_RLS01_AGENCIES_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
