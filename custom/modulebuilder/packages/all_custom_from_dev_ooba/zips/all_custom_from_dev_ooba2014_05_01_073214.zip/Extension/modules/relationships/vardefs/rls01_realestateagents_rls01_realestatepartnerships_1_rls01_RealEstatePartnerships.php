<?php
// created: 2014-04-28 00:44:49
$dictionary["rls01_RealEstatePartnerships"]["fields"]["rls01_realestateagents_rls01_realestatepartnerships_1"] = array (
  'name' => 'rls01_realestateagents_rls01_realestatepartnerships_1',
  'type' => 'link',
  'relationship' => 'rls01_realestateagents_rls01_realestatepartnerships_1',
  'source' => 'non-db',
  'module' => 'rls01_RealEstateAgents',
  'bean_name' => 'rls01_RealEstateAgents',
  'vname' => 'LBL_RLS01_REALESTATEAGENTS_RLS01_REALESTATEPARTNERSHIPS_1_FROM_RLS01_REALESTATEAGENTS_TITLE',
);
