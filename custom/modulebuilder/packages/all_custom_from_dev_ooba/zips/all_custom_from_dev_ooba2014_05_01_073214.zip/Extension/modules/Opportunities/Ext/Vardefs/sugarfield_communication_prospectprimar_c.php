<?php
 // created: 2014-05-01 01:48:13
$dictionary['Opportunity']['fields']['communication_prospectprimar_c']['labelValue']='Communication Prospect';
$dictionary['Opportunity']['fields']['communication_prospectprimar_c']['dependency']='';

 ?>