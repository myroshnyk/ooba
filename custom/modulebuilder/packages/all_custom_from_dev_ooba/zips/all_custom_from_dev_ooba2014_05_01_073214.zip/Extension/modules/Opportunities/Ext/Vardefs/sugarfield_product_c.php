<?php
 // created: 2014-05-01 01:51:28
$dictionary['Opportunity']['fields']['product_c']['labelValue']='Product Category';
$dictionary['Opportunity']['fields']['product_c']['enforced']='';
$dictionary['Opportunity']['fields']['product_c']['dependency']='';

 ?>