<?php
 // created: 2014-04-30 12:09:52
$dictionary['Opportunity']['fields']['sales_territory_c']['labelValue']='Sales Territory';
$dictionary['Opportunity']['fields']['sales_territory_c']['dependency']='';
$dictionary['Opportunity']['fields']['sales_territory_c']['visibility_grid']='';

 ?>