<?php
 // created: 2014-04-30 12:09:51
$dictionary['Opportunity']['fields']['communication_representative_c']['labelValue']=' ooba Representative';
$dictionary['Opportunity']['fields']['communication_representative_c']['dependency']='';

 ?>