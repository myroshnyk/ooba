<?php 
 // created: 2014-05-01 07:32:08
$mod_strings['LBL_ENTERPRISE_ID'] = 'Suburb No e';

?>
