<?php 
 // created: 2014-05-01 07:31:56
$mod_strings['LBL_DOCUMENT_INFORMATION'] = 'Overview';
$mod_strings['LBL_DET_IS_TEMPLATE'] = 'Template';

?>
