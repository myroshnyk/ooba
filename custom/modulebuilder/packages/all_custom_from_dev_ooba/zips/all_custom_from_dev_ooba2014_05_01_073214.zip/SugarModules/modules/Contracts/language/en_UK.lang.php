<?php 
 // created: 2014-05-01 07:31:55
$mod_strings['LBL_CONTRACT_INFORMATION'] = 'Overview';

?>
