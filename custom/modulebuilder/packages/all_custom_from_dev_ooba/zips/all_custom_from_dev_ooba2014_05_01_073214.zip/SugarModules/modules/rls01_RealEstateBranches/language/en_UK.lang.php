<?php 
 // created: 2014-05-01 07:32:07
$mod_strings['LBL_ACCOUNT_INFORMATION'] = 'Overview';
$mod_strings['LBL_ADDRESS_INFORMATION'] = 'Address Detail';
$mod_strings['LBL_EMAIL_ADDRESSES'] = 'Other';
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'Province:';
$mod_strings['LBL_PHONE_ALT'] = 'Other Phone:';
$mod_strings['LBL_RLS01_AGENCIES_RLS01_BRANCHES_FROM_RLS01_REALESTATEAGENCIES_TITLE'] = 'Estate Agency';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Name';
$mod_strings['LBL_RLS01_AGENCIES_RLS01_BRANCHES_FROM_RLS01_AGENCIES_TITLE'] = 'Agency';
$mod_strings['LBL_PHONE'] = 'Office Phone';
$mod_strings['LBL_PHONE_FAX'] = 'Fax';

?>
