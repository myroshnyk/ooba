<?php

class myCustomLogicHook extends SugarBean
{
  function leadSourceCorrect (SugarBean $bean, $event, $arguments)
  {             
    if ($bean->lead_source_ooba_c == 'Real_Estate') {                                   
      $bean->lead_provider_c = '';        $bean->contact_id_c = ''; 
      $bean->lead_provider_resource_c = '';   $bean->rls01_resources_id1_c = '';                                  
    }
    else {                                                                           
      $bean->lead_provider_agent_c = '';  $bean->rls01_agents_id_c = '';
      $bean->rls01_branches_id_c = '';
      $bean->rls01_agencies_id_c = ''; 
      
      if ($bean->lead_source_ooba_c == 'Staff') {     
        $bean->lead_provider_c = '';        $bean->contact_id_c = '';   
      }
      else {                                                         
        $bean->lead_provider_resource_c = '';   $bean->rls01_resources_id1_c = '';                            
      }
    }
    
   // $bean->phone_number_c = $_REQUEST['phone_code_c'] . $bean->phone_number_c;
  }
}
?>
