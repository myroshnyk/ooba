<?php 
 // created: 2014-05-01 07:31:52
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'Province:';

?>
