<?php
 // created: 2014-04-30 12:09:51
$dictionary['Opportunity']['fields']['agency_c']['labelValue']='Agency';
$dictionary['Opportunity']['fields']['agency_c']['dependency']='';

 ?>