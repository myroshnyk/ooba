<?php
 // created: 2014-04-30 12:09:51
$dictionary['Lead']['fields']['lead_provider_agent_c']['labelValue']='Lead Provider (Agent)';
$dictionary['Lead']['fields']['lead_provider_agent_c']['dependency']='';

 ?>