<?php
 // created: 2014-05-01 00:37:50
$dictionary['rls01_RealEstateBranches']['fields']['phone_alternate']['full_text_search']=array (
);

 ?>