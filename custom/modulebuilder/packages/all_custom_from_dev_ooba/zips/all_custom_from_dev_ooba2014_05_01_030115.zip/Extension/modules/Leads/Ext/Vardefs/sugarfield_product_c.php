<?php
 // created: 2014-04-30 12:09:51
$dictionary['Lead']['fields']['product_c']['labelValue']='Product t';
$dictionary['Lead']['fields']['product_c']['enforced']='';
$dictionary['Lead']['fields']['product_c']['dependency']='';

 ?>