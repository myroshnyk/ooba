<?php
 // created: 2014-04-30 12:09:51
$dictionary['Lead']['fields']['lead_status_c']['labelValue']='Status';
$dictionary['Lead']['fields']['lead_status_c']['dependency']='';
$dictionary['Lead']['fields']['lead_status_c']['visibility_grid']='';

 ?>