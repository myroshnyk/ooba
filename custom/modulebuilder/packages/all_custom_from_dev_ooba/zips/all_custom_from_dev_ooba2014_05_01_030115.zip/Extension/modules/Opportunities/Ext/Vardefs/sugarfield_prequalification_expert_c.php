<?php
 // created: 2014-04-30 12:09:52
$dictionary['Opportunity']['fields']['prequalification_expert_c']['labelValue']='Prequalification Expert';
$dictionary['Opportunity']['fields']['prequalification_expert_c']['dependency']='';

 ?>