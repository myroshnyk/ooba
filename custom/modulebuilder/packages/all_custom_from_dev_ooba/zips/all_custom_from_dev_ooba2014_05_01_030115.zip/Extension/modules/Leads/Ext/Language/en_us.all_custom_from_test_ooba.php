<?php 
 // created: 2014-04-30 11:28:21
$mod_strings['LBL_COMMUNICATION_REPRESENTATIVE_USER_ID'] = ' ooba Representative (related User ID)';
$mod_strings['LBL_COMMUNICATION_REPRESENTATIVE'] = ' ooba Representative';

?>
