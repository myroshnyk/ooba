<?php 
 // created: 2014-04-28 01:21:37
$mod_strings['LBL_ACCOUNT_MANAGER_KAM_RLS01_RESOURCES_ID'] = 'Account Manager (KAM) (related  ID)';
$mod_strings['LBL_ACCOUNT_MANAGER_KAM'] = 'Account Manager (KAM)';

?>
