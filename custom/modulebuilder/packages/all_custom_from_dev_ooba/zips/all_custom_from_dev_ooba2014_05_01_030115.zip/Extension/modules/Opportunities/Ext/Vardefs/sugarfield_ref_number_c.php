<?php
 // created: 2014-04-30 12:09:52
$dictionary['Opportunity']['fields']['ref_number_c']['labelValue']='Ref Number';
$dictionary['Opportunity']['fields']['ref_number_c']['enforced']='';
$dictionary['Opportunity']['fields']['ref_number_c']['dependency']='';

 ?>