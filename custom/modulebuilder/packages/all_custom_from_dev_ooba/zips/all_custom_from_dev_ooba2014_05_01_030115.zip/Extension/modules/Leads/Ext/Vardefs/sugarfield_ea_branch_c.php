<?php
 // created: 2014-04-30 12:09:51
$dictionary['Lead']['fields']['ea_branch_c']['labelValue']='EA Branch';
$dictionary['Lead']['fields']['ea_branch_c']['dependency']='';

 ?>