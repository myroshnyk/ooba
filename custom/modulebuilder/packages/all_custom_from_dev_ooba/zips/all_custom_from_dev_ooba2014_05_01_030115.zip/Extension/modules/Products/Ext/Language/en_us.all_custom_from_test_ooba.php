<?php 
 // created: 2014-04-30 11:28:23
$mod_strings['LBL_CONTRACTS'] = 'Installed Products';
$mod_strings['LBL_CONTRACTS_SUBPANEL_TITLE'] = 'Installed Products';

?>
