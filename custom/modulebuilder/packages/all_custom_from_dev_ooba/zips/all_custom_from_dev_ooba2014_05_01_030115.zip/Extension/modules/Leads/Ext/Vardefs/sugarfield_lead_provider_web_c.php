<?php
 // created: 2014-04-30 17:54:28
$dictionary['Lead']['fields']['lead_provider_web_c']['labelValue']='Lead Provider (Web Entity)';
$dictionary['Lead']['fields']['lead_provider_web_c']['dependency']='';

 ?>