<?php 
 // created: 2014-04-23 12:50:27
$mod_strings['LBL_PANEL_ADVANCED'] = 'Prospect';
$mod_strings['LBL_PRODUCT_PRODUCTTEMPLATE_ID'] = 'Product (related  ID)';
$mod_strings['LBL_PRODUCT'] = 'Product';
$mod_strings['LBL_LEAD_STATUS'] = 'Status';
$mod_strings['LBL_STAGE'] = 'Stage';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Source';
$mod_strings['LBL_TERRITORY'] = 'Sales Territory';
$mod_strings['LBL_PHONE_TYPE'] = 'Phone Type';
$mod_strings['LBL_ID_TYPE'] = 'ID Type';
$mod_strings['LBL_AGENCY'] = 'Agency';
$mod_strings['LBL_EA_BRANCH'] = 'EA Branch';
$mod_strings['LBL_PREQUALIFICATION_EXPERT_USER_ID'] = 'Prequalification Expert (related User ID)';
$mod_strings['LBL_PREQUALIFICATION_EXPERT'] = 'Prequalification Expert';
$mod_strings['LBL_LEAD_PROVIDER_CONTACT_ID'] = 'Lead Provider (related Contact ID)';
$mod_strings['LBL_LEAD_PROVIDER'] = 'Lead Provider';
$mod_strings['LBL_LEAD_PROVIDER_AGENT'] = 'Lead Provider (Agent)';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_OFFICE_PHONE'] = 'Phone';
$mod_strings['LBL_ENTERPRISE_ID'] = 'enterprise_id';
$mod_strings['LBL_REF_NUMBER'] = 'Ref Number';
$mod_strings['LBL_ID_NUMBER'] = 'ID Number';
$mod_strings['LBL_LINKED_TO_LEAD_LEAD_ID'] = 'Linked to Lead (related Lead ID)';
$mod_strings['LBL_LINKED_TO_LEAD'] = 'Linked to Lead';
$mod_strings['LBL_LINKED_TO_BOND'] = 'Linked to Bond';
$mod_strings['LBL_BOND_STATUS'] = 'Bond Status';
$mod_strings['LBL_DESIRED_AMOUNT'] = 'Desired Amount';
$mod_strings['LBL_LIST_PHONE'] = 'Phone';
$mod_strings['LBL_REFFERER_RLS01_RESOURCES_ID'] = 'Refferer (related  ID)';
$mod_strings['LBL_REFFERER'] = 'Refferer';
$mod_strings['LBL_CONTACT_CONTACT_ID'] = 'Contact (related Contact ID)';
$mod_strings['LBL_CONTACT'] = 'Contact';
$mod_strings['LBL_LEAD_PROVIDER_AGENT_RLS01_AGENTS_ID'] = 'Lead Provider (Agent) (related  ID)';
$mod_strings['LBL_LEAD_PROVIDER_RESOURCE_RLS01_RESOURCES_ID'] = 'Lead Provider (Resource) (related  ID)';
$mod_strings['LBL_LEAD_PROVIDER_RESOURCE'] = 'Lead Provider (Resource)';
$mod_strings['LBL_AGENCY_RLS01_AGENCIES_ID'] = 'Agency (related  ID)';
$mod_strings['LBL_EA_BRANCH_RLS01_BRANCHES_ID'] = 'EA Branch (related  ID)';

?>
