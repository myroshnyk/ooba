<?php
 // created: 2014-04-30 12:09:52
$dictionary['Opportunity']['fields']['lead_provider_c']['labelValue']='Lead Provider';
$dictionary['Opportunity']['fields']['lead_provider_c']['dependency']='';

 ?>