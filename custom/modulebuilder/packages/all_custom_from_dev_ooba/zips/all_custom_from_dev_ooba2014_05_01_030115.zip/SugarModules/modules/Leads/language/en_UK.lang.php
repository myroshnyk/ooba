<?php 
 // created: 2014-05-01 03:00:59
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Overview';
$mod_strings['LBL_LEAD_PROVIDER_WEB_RLS01_WEBENTITIES_ID'] = 'Lead Provider (Web Entity) (related  ID)';
$mod_strings['LBL_LEAD_PROVIDER_WEB'] = 'Lead Provider (Web Entity)';

?>
