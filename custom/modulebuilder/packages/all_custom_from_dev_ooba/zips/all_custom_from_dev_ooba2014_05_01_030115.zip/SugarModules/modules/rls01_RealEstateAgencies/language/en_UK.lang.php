<?php 
 // created: 2014-05-01 03:01:07
$mod_strings['LBL_ACCOUNT_INFORMATION'] = 'Overview';
$mod_strings['LBL_ADDRESS_INFORMATION'] = 'Address Detail - Billing';
$mod_strings['LBL_DESCRIPTION_INFORMATION'] = 'Other';
$mod_strings['LBL_EMAIL_ADDRESSES'] = 'Address Detail - Shipping';
$mod_strings['LBL_COPY_ADDRESS_FROM_UP'] = 'Copy address from above';
$mod_strings['LBL_TRADING_NAME'] = 'Trading Name';
$mod_strings['LBL_BUILDING_COMPLEX_NAME'] = 'Building / Complex Name';
$mod_strings['LBL_FLOOR'] = 'Floor #';
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'Province:';
$mod_strings['LBL_SUBURB_POST_OFFICE_2'] = 'Suburb / post office';
$mod_strings['LBL_SHIPPING_ADDRESS_STATE'] = 'Province:';
$mod_strings['LBL_PHONE'] = 'Office Phone';
$mod_strings['LBL_PHONE_FAX'] = 'Fax';

?>
