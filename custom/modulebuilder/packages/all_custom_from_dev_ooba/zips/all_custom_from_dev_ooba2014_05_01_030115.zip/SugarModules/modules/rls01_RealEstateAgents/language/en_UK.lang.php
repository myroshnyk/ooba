<?php 
 // created: 2014-05-01 03:01:08
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Overview';
$mod_strings['LBL_ADDRESS_INFORMATION'] = 'Other';
$mod_strings['LBL_PRIMARY_ADDRESS_STATE'] = 'Province';
$mod_strings['LBL_ALT_ADDRESS_STATE'] = 'Province';
$mod_strings['LBL_MOBILE_PHONE'] = 'Mobile';
$mod_strings['LBL_RLS01_BRANCHES_RLS01_AGENTS_FROM_RLS01_REALESTATEBRANCHES_TITLE'] = 'Estate Agency Branch';
$mod_strings['LBL_RLS01_BRANCHES_RLS01_AGENTS_FROM_RLS01_BRANCHES_TITLE'] = 'Branch';

?>
