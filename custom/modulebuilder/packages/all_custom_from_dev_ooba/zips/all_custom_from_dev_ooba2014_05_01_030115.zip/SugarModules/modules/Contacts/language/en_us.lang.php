<?php 
 // created: 2014-05-01 03:00:57
$mod_strings['LBL_SACITIZEN'] = 'SA Citizen';
$mod_strings['LBL_LAST_CREDIT_CHECK_PERFORMED'] = 'Last Credit Check Performed';

?>
