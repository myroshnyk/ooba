<?php 
 // created: 2014-05-01 03:00:57
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Overview';
$mod_strings['LBL_CREDIT_OUTCOME'] = 'Credit outcome (Passed)';
$mod_strings['LBL_HOME_PHONE'] = 'Home Phone:';
$mod_strings['LBL_BIRTHDATE'] = 'Date of birth:';
$mod_strings['LBL_OFFICE_PHONE'] = 'Work Phone:';
$mod_strings['LBL_DO_NOT_CALL'] = 'Communication Opt out [Do not call]:';
$mod_strings['LBL_ID_NUMBER'] = 'ID Number';
$mod_strings['LBL_PRIMARY_ADDRESS_STATE'] = 'Province:';
$mod_strings['LBL_ALT_ADDRESS_STATE'] = 'Province:';

?>
