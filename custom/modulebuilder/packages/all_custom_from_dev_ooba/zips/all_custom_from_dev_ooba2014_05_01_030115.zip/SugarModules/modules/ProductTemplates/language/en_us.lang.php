<?php 
 // created: 2014-05-01 03:01:03
$mod_strings['LBL_ENTERPRISE_ID'] = 'ooba Product Code';

?>
