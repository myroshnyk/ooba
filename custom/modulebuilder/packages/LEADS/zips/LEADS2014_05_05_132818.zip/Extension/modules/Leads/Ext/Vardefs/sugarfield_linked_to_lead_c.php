<?php
 // created: 2014-05-02 00:38:39
$dictionary['Lead']['fields']['linked_to_lead_c']['labelValue']='Linked to Lead';
$dictionary['Lead']['fields']['linked_to_lead_c']['dependency']='';

 ?>