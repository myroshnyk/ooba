<?php
 // created: 2014-05-02 00:38:39
$dictionary['Lead']['fields']['id_number_c']['labelValue']='ID Number';
$dictionary['Lead']['fields']['id_number_c']['enforced']='';
$dictionary['Lead']['fields']['id_number_c']['dependency']='';

 ?>