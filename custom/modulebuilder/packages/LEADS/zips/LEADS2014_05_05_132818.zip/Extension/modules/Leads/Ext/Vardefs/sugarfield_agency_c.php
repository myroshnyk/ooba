<?php
 // created: 2014-05-02 03:35:13
$dictionary['Lead']['fields']['agency_c']['labelValue']='Agency';
$dictionary['Lead']['fields']['agency_c']['dependency']='equal($lead_source,"REAL_ESTATE")';

 ?>