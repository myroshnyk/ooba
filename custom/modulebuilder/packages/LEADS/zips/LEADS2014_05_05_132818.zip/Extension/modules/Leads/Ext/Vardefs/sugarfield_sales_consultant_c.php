<?php
 // created: 2014-05-02 02:49:54
$dictionary['Lead']['fields']['sales_consultant_c']['labelValue']='Prequalification Expert';
$dictionary['Lead']['fields']['sales_consultant_c']['dependency']='';

 ?>