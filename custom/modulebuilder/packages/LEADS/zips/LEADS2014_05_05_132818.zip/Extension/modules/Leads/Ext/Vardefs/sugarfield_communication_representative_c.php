<?php
 // created: 2014-05-02 02:49:04
$dictionary['Lead']['fields']['communication_representative_c']['labelValue']='ooba Representative';
$dictionary['Lead']['fields']['communication_representative_c']['dependency']='';

 ?>