<?php
 // created: 2014-05-02 03:06:00
$dictionary['Lead']['fields']['lead_provider_agent_c']['labelValue']='Lead Provider (Agent)';
$dictionary['Lead']['fields']['lead_provider_agent_c']['dependency']='equal($lead_source,"REAL_ESTATE")';

 ?>