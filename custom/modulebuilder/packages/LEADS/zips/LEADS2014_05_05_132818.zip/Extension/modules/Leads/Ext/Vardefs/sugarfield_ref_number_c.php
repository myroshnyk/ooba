<?php
 // created: 2014-05-05 13:05:33
$dictionary['Lead']['fields']['ref_number_c']['labelValue']='Ref Number';
$dictionary['Lead']['fields']['ref_number_c']['enforced']='';
$dictionary['Lead']['fields']['ref_number_c']['dependency']='';

 ?>