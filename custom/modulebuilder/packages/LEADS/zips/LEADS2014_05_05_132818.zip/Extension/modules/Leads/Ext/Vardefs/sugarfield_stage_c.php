<?php
 // created: 2014-05-02 00:38:39
$dictionary['Lead']['fields']['stage_c']['labelValue']='Stage';
$dictionary['Lead']['fields']['stage_c']['dependency']='';
$dictionary['Lead']['fields']['stage_c']['visibility_grid']='';

 ?>