<?php
 // created: 2014-05-01 20:48:54
$dictionary['Lead']['fields']['lead_source']['audited']=false;
$dictionary['Lead']['fields']['lead_source']['options']='lead_source';
$dictionary['Lead']['fields']['lead_source']['merge_filter']='disabled';
$dictionary['Lead']['fields']['lead_source']['calculated']=false;
$dictionary['Lead']['fields']['lead_source']['dependency']=false;
$dictionary['Lead']['fields']['lead_source']['required']=true;
$dictionary['Lead']['fields']['lead_source']['comments']='Lead source (ex: Web, print)';

 ?>