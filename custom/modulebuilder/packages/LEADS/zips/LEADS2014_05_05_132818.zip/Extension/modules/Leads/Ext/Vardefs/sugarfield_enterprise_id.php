<?php
 // created: 2014-05-01 13:00:28
$dictionary['Lead']['fields']['enterprise_id']=
 array (
    'required' => false,
    'name' => 'enterprise_id',
    'vname' => 'LBL_ENTERPRISE_ID',
    'type' => 'varchar',
    'massupdate' => 0,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => false,
    'reportable' => true,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'calculated' => false,
    'len' => '255',
    'size' => '20',
  );