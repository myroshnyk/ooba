<?php
 // created: 2014-05-04 12:55:17
$dictionary['Lead']['fields']['lost_reason_c']['labelValue']='Lost Reason';
$dictionary['Lead']['fields']['lost_reason_c']['visibility_grid']=array (
  'trigger' => 'status',
  'values' => 
  array (
    '' => 
    array (
      0 => '',
    ),
    'NEW' => 
    array (
      0 => '',
    ),
    'ASSIGN' => 
    array (
      0 => '',
    ),
    'QUALIFY' => 
    array (
      0 => '',
    ),
    'LOST' => 
    array (
      0 => 'WRONG_PROSPECT',
      1 => 'NO_CONTACT',
      2 => 'TARGET_PRODUCT_EXISTS',
      3 => 'DUP_LEAD',
      4 => 'NO_PROD_INTEREST',
    ),
    'CONVERTED' => 
    array (
      0 => '',
    ),
  ),
);

 ?>