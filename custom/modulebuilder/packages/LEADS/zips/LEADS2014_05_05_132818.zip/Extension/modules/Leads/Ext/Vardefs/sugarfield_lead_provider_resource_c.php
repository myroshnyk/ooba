<?php
 // created: 2014-05-02 03:08:35
$dictionary['Lead']['fields']['lead_provider_resource_c']['labelValue']='Lead Provider (Resource)';
$dictionary['Lead']['fields']['lead_provider_resource_c']['dependency']='equal($lead_source,"STAFF")';

 ?>