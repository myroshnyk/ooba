<?php
 // created: 2014-05-03 09:11:45
$dictionary['Lead']['fields']['product_c']['labelValue']='Product Category';
$dictionary['Lead']['fields']['product_c']['enforced']='';
$dictionary['Lead']['fields']['product_c']['dependency']='';

 ?>