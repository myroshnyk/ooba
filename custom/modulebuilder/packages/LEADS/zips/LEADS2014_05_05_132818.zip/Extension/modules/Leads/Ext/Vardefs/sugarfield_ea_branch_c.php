<?php
 // created: 2014-05-02 03:35:31
$dictionary['Lead']['fields']['ea_branch_c']['labelValue']='EA Branch';
$dictionary['Lead']['fields']['ea_branch_c']['dependency']='equal($lead_source,"REAL_ESTATE")';

 ?>