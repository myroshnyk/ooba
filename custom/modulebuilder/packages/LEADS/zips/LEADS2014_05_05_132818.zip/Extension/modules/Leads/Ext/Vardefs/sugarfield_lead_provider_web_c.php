<?php
 // created: 2014-05-02 05:04:20
$dictionary['Lead']['fields']['lead_provider_web_c']['labelValue']='Lead Provider (Web Entity)';
$dictionary['Lead']['fields']['lead_provider_web_c']['dependency']='equal($lead_source,"WEB_SITE")';

 ?>