<?php
 // created: 2014-05-02 00:38:39
$dictionary['Lead']['fields']['desired_amount_c']['labelValue']='Desired Amount';
$dictionary['Lead']['fields']['desired_amount_c']['enforced']='';
$dictionary['Lead']['fields']['desired_amount_c']['dependency']='';

 ?>