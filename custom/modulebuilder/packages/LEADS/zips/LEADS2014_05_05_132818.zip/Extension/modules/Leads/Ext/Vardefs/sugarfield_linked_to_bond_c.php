<?php
 // created: 2014-05-02 00:38:39
$dictionary['Lead']['fields']['linked_to_bond_c']['labelValue']='Linked to Bond';
$dictionary['Lead']['fields']['linked_to_bond_c']['enforced']='';
$dictionary['Lead']['fields']['linked_to_bond_c']['dependency']='';

 ?>