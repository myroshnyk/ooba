<?php
 // created: 2014-05-02 00:38:39
$dictionary['Lead']['fields']['contact_c']['labelValue']='Contact';
$dictionary['Lead']['fields']['contact_c']['dependency']='';

 ?>