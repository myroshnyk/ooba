<?php
 // created: 2014-05-02 00:38:39
$dictionary['Lead']['fields']['phone_type_c']['labelValue']='Phone Type';
$dictionary['Lead']['fields']['phone_type_c']['dependency']='';
$dictionary['Lead']['fields']['phone_type_c']['visibility_grid']='';

 ?>