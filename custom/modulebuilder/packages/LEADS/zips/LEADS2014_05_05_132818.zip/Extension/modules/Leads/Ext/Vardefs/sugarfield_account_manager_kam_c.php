<?php
 // created: 2014-05-02 09:32:34
$dictionary['Lead']['fields']['account_manager_kam_c']['labelValue']='Account Manager (KAM)';
$dictionary['Lead']['fields']['account_manager_kam_c']['dependency']='equal($lead_source,"REAL_ESTATE")';

 ?>