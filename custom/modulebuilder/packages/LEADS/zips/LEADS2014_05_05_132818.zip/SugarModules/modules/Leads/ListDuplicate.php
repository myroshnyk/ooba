<button id="zip_send" class="rls_btn_right" onclick="window.location.href = 'index.php?module=Leads&record=<?php echo $_REQUEST['record']; ?>&action=DetailView'"><?php echo $mod_strings['LBL_FINDE_CANCEL'];?></button>
<?php
//echo phpinfo();
$client = new SoapClient("https://devpartner.ooba.co.za/sugar-crm/SugarCRMCreditCheck/CreditCheckService?WSDL");
//$client = new SoapClient("https://devpartner.ooba.co.za/sugar-crm/SugarCRMProductSearch/ProductSearchService?WSDL", 
//        array('login' => "sugarcrm", 'password' => "password01","trace"=> 1, "exceptions" => 0,'allow_self_signed' => true, 'verify_peer' => false,'local_cert' => 'https://devpartner.ooba.co.za',));

print_r($client->__getFunctions());

/*
$client = new SoapClient("http://www.cbr.ru/dailyinfowebserv/dailyinfo.asmx?WSDL");
echo 'SOAP Client='.$client->sdl;
 */