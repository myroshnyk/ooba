<?php 
 // created: 2014-05-05 13:28:17
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Overview';
$mod_strings['LBL_ID_TYPE'] = 'ID Type';
$mod_strings['LBL_STAGE'] = 'Stage';
$mod_strings['LBL_STATUS'] = 'Status_original:';
$mod_strings['LBL_LEAD_STATUS'] = 'Status';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Source:';
$mod_strings['LBL_PHONE_TYPE'] = 'Phone Type';
$mod_strings['LBL_COMMUNICATION_REPRESENTATIVE_RLS01_RESOURCES_ID'] = 'ooba Representative (related  ID)';
$mod_strings['LBL_COMMUNICATION_REPRESENTATIVE'] = 'ooba Representative';
$mod_strings['LBL_SALES_CONSULTANT_RLS01_RESOURCES_ID'] = 'Prequalification Expert (related  ID)';
$mod_strings['LBL_SALES_CONSULTANT'] = 'Prequalification Expert';
$mod_strings['LBL_LEAD_PROVIDER_AGENT'] = 'Lead Provider (Agent)';
$mod_strings['LBL_LEAD_PROVIDER_RESOURCE'] = 'Lead Provider (Resource)';
$mod_strings['LBL_AGENCY'] = 'Agency';
$mod_strings['LBL_EA_BRANCH'] = 'EA Branch';
$mod_strings['LBL_PRODUCT'] = 'Product Category';
$mod_strings['LBL_LEAD_PROVIDER_WEB_RLS01_WEBENTITIES_ID'] = 'Lead Provider (Web Entity) (related  ID)';
$mod_strings['LBL_LEAD_PROVIDER_WEB '] = 'Lead Provider (Web Entity)';
$mod_strings['LBL_ACCOUNT_MANAGER_KAM_C_RLS01_RESOURCES_ID'] = 'Account Manager (KAM) (related  ID)';
$mod_strings['LBL_ACCOUNT_MANAGER_KAM_C'] = 'Account Manager (KAM)';
$mod_strings['LBL_LEAD_PROVIDER'] = 'Lead Provider';
$mod_strings['LBL_LOST_REASON_C'] = 'Lost Reason';

?>
