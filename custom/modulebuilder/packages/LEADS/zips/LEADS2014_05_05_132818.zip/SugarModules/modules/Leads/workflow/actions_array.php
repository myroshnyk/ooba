<?php
//Workflow Action Meta Data Arrays 
$action_meta_array = array ( 

'Leads0_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'status' => 'NEW', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

); 

 

?>