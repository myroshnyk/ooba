<?php

include_once("include/workflow/alert_utils.php");
include_once("include/workflow/action_utils.php");
include_once("include/workflow/time_utils.php");
include_once("include/workflow/trigger_utils.php");
//BEGIN WFLOW PLUGINS
include_once("include/workflow/custom_utils.php");
//END WFLOW PLUGINS
	class Leads_workflow {
	function process_wflow_triggers(& $focus){
		include("custom/modules/Leads/workflow/triggers_array.php");
		include("custom/modules/Leads/workflow/alerts_array.php");
		include("custom/modules/Leads/workflow/actions_array.php");
		include("custom/modules/Leads/workflow/plugins_array.php");
		if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="21d48fd2-e68a-c62c-ca42-53675ccba92b")){ 
 
 if( ( !($focus->fetched_row['status'] ==  '' )) && 
 (isset($focus->status) && $focus->status ==  '')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 

	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['9464681e_f7e8_07a5_b8cb_53675cbcb2bd'])){
		$triggeredWorkflows['9464681e_f7e8_07a5_b8cb_53675cbcb2bd'] = true;
		 process_workflow_actions($focus, $action_meta_array['Leads0_action0']); 
 	$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ());	}
 

	 //End Frame Secondary 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


	//end function process_wflow_triggers
	}

	//end class
	}

?>