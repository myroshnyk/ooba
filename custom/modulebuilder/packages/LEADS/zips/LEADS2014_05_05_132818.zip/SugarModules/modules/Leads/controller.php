<?php
/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (“MSA”), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/
require_once 'modules/Leads/controller.php';
require_once 'custom/include/rls/WSSoapClient.php';
class CustomLeadsController extends LeadsController{
function action_ProductSearchService(){
$soapURL = $GLOBALS['sugar_config']['soap_settings']['product_search_service'];
$soapLogin = $GLOBALS['sugar_config']['soap_settings']['soap_login'];
$soapPasword = $GLOBALS['sugar_config']['soap_settings']['soap_pasword'];

$soapParameters=array('soap_version'=> SOAP_1_1,
                      'style'=> SOAP_DOCUMENT,
                      'use'=> SOAP_LITERAL,
                      'exceptions'=> 1,
                      'trace'=> 1);
$soapFunction = "process" ;
$soapFunctionParameters = array("Id"=>$this->record,"ModuleName"=>$this->module) ;
try {
    $soapClient = new WSSoapClient($soapURL,$soapParameters);
    $soapClient->__setUsernameToken($soapLogin, $soapPasword, 'PasswordText');
    $soapResult=$soapClient->__soapCall($soapFunction,array("parameters"=>$soapFunctionParameters));    
}
catch (Exception $ex) {
    $GLOBALS['log']->test("SOAP_EX: " .$ex->getMessage() . "\n");
}
$GLOBALS['log']->test("SOAP_REQUEST: " .$soapClient->__getLastRequest() . "\n");
$GLOBALS['log']->test("SOAP_RESULT: " .$soapResult->StatusCode . "\n");
$this->view = 'detail';
$this->view_object_map['request'] = "REQUEST:\n".$soapClient->__getLastRequest(). "\n";
$this->view_object_map['result'] = "RESULT:\n" . $soapResult->StatusCode . "\n";
$this->view_object_map['msg'] = "Duplicate check performed. No Duplicates Found.\n";
}	
}
?>
