<?php 
$app_list_strings['lead_source'] = array (
  '' => '',
  'EMAIL' => 'e-mail',
  'WALK_IN' => 'Prospect walk in',
  'WEB_FORM' => 'Web Form',
  'WEB_SITE' => 'Web Site',
  'TELEPHONE' => 'Telephone',
  'REAL_ESTATE' => 'Real Estate',
  'STAFF' => 'Staff',
);$app_list_strings['lead_status'] = array (
  '' => '',
  'NEW' => 'New',
  'ASSIGN' => 'Assigned',
  'QUALIFY' => 'Qualifying',
  'LOST' => 'Lost',
  'CONVERTED' => 'Converted/Won',
);$app_list_strings['lost_reason'] = array (
  '' => '',
  'WRONG_PROSPECT' => 'Incorrect Prospect',
  'NO_CONTACT' => 'Not Contactable',
  'TARGET_PRODUCT_EXISTS' => 'No longer possible. Target product exists',
  'DUP_LEAD' => 'Duplicate Lead',
  'NO_PROD_INTEREST' => 'No Product Interest',
);