<?php 
 // created: 2014-04-23 12:50:34
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Overview';
$mod_strings[1] = 'Other';
$mod_strings['LBL_LIST_PRICE'] = 'Value';

?>
