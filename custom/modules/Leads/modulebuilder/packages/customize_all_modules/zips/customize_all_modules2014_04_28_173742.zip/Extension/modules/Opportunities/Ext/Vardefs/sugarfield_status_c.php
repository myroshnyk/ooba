<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['status_c']['labelValue']='Status';
$dictionary['Opportunity']['fields']['status_c']['dependency']='';
$dictionary['Opportunity']['fields']['status_c']['visibility_grid']='';

 ?>