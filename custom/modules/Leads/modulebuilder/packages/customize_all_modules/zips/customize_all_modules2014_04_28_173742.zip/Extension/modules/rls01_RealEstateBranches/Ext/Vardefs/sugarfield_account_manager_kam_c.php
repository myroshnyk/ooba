<?php
 // created: 2014-04-28 04:56:59
$dictionary['rls01_RealEstateBranches']['fields']['account_manager_kam_c']['labelValue']='Account Manager (KAM)';
$dictionary['rls01_RealEstateBranches']['fields']['account_manager_kam_c']['dependency']='';

 ?>