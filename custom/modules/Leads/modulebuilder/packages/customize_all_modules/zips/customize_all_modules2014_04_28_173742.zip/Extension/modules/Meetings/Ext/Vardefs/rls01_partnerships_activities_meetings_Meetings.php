<?php
// created: 2014-04-25 15:05:06
$dictionary["Meeting"]["fields"]["rls01_partnerships_activities_meetings"] = array (
  'name' => 'rls01_partnerships_activities_meetings',
  'type' => 'link',
  'relationship' => 'rls01_partnerships_activities_meetings',
  'source' => 'non-db',
  'module' => 'rls01_Partnerships',
  'bean_name' => false,
  'vname' => 'LBL_RLS01_PARTNERSHIPS_ACTIVITIES_MEETINGS_FROM_RLS01_PARTNERSHIPS_TITLE',
);
