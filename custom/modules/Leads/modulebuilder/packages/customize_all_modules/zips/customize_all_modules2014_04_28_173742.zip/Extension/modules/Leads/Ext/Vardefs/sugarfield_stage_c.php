<?php
 // created: 2014-04-28 04:58:07
$dictionary['Lead']['fields']['stage_c']['labelValue']='Stage';
$dictionary['Lead']['fields']['stage_c']['dependency']='';
$dictionary['Lead']['fields']['stage_c']['visibility_grid']='';

 ?>