<?php
 // created: 2014-04-28 04:58:06
$dictionary['Lead']['fields']['id_type_c']['labelValue']='ID Type';
$dictionary['Lead']['fields']['id_type_c']['dependency']='';
$dictionary['Lead']['fields']['id_type_c']['visibility_grid']='';

 ?>