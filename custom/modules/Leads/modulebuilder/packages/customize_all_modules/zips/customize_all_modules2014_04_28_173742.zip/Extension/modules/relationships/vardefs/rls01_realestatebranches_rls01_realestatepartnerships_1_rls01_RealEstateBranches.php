<?php
// created: 2014-04-28 00:46:22
$dictionary["rls01_RealEstateBranches"]["fields"]["rls01_realestatebranches_rls01_realestatepartnerships_1"] = array (
  'name' => 'rls01_realestatebranches_rls01_realestatepartnerships_1',
  'type' => 'link',
  'relationship' => 'rls01_realestatebranches_rls01_realestatepartnerships_1',
  'source' => 'non-db',
  'module' => 'rls01_RealEstatePartnerships',
  'bean_name' => 'rls01_RealEstatePartnerships',
  'side' => 'right',
  'vname' => 'LBL_RLS01_REALESTATEBRANCHES_RLS01_REALESTATEPARTNERSHIPS_1_FROM_RLS01_REALESTATEPARTNERSHIPS_TITLE',
);
