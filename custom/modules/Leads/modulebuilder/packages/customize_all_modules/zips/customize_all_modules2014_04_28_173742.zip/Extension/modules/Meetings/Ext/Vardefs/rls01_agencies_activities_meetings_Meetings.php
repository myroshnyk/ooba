<?php
// created: 2014-04-23 10:20:56
$dictionary["Meeting"]["fields"]["rls01_agencies_activities_meetings"] = array (
  'name' => 'rls01_agencies_activities_meetings',
  'type' => 'link',
  'relationship' => 'rls01_agencies_activities_meetings',
  'source' => 'non-db',
  'module' => 'rls01_Agencies',
  'bean_name' => false,
  'vname' => 'LBL_RLS01_AGENCIES_ACTIVITIES_MEETINGS_FROM_RLS01_AGENCIES_TITLE',
);
