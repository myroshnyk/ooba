<?php
// created: 2014-04-28 01:04:48
$dictionary["rls01_RealEstateBranches"]["fields"]["rls01_realestatebranches_rls01_realestatepartnerships_2"] = array (
  'name' => 'rls01_realestatebranches_rls01_realestatepartnerships_2',
  'type' => 'link',
  'relationship' => 'rls01_realestatebranches_rls01_realestatepartnerships_2',
  'source' => 'non-db',
  'module' => 'rls01_RealEstatePartnerships',
  'bean_name' => 'rls01_RealEstatePartnerships',
  'side' => 'right',
  'vname' => 'LBL_RLS01_REALESTATEBRANCHES_RLS01_REALESTATEPARTNERSHIPS_2_FROM_RLS01_REALESTATEPARTNERSHIPS_TITLE',
);
