<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['lead_provider_c']['labelValue']='Lead Provider';
$dictionary['Opportunity']['fields']['lead_provider_c']['dependency']='';

 ?>