<?php 
 // created: 2014-04-29 14:43:49
$mod_strings['LBL_COMMUNICATION_REPRESENTATIVE_RLS01_RESOURCES_ID'] = ' ooba Representative (related  ID)';
$mod_strings['LBL_COMMUNICATION_REPRESENTATIVE'] = ' ooba Representative';
$mod_strings['LBL_SALES_CONSULTANT_RLS01_RESOURCES_ID'] = 'Prequalification Expert (related  ID)';
$mod_strings['LBL_SALES_CONSULTANT'] = 'Prequalification Expert';

?>
