<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['prequalification_expert_c']['labelValue']='Prequalification Expert';
$dictionary['Opportunity']['fields']['prequalification_expert_c']['dependency']='';

 ?>