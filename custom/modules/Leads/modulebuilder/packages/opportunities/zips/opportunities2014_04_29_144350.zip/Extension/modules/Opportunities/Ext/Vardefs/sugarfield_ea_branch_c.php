<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['ea_branch_c']['labelValue']='EA Branch';
$dictionary['Opportunity']['fields']['ea_branch_c']['dependency']='';

 ?>