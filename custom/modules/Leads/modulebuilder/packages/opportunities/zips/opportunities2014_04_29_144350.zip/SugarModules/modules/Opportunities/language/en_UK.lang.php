<?php 
 // created: 2014-04-29 14:43:49
$mod_strings['LBL_AMOUNT'] = 'Desired Amount';
$mod_strings['LBL_DESCRIPTION'] = 'Comments';
$mod_strings['LBL_COMMUNICATION_PROSPECTPRIMAR_CONTACT_ID'] = 'Communication ProspectPrimary Lead (related Contact ID)';
$mod_strings['LBL_COMMUNICATION_PROSPECTPRIMAR'] = 'Communication ProspectPrimary Lead';

?>
