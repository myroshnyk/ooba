<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['ref_number_c']['labelValue']='Ref Number';
$dictionary['Opportunity']['fields']['ref_number_c']['enforced']='';
$dictionary['Opportunity']['fields']['ref_number_c']['dependency']='';

 ?>