<?php
 // created: 2014-04-28 05:07:24
$dictionary['Opportunity']['fields']['communication_representative_c']['labelValue']=' ooba Representative';
$dictionary['Opportunity']['fields']['communication_representative_c']['dependency']='';

 ?>