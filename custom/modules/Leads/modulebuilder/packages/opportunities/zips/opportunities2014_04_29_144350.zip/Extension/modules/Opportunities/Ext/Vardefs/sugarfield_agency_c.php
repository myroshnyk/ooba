<?php
 // created: 2014-04-28 04:58:07
$dictionary['Opportunity']['fields']['agency_c']['labelValue']='Agency';
$dictionary['Opportunity']['fields']['agency_c']['dependency']='';

 ?>