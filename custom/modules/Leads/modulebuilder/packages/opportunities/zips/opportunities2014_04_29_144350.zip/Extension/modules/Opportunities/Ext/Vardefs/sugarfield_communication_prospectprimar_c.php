<?php
 // created: 2014-04-29 14:27:04
$dictionary['Opportunity']['fields']['communication_prospectprimar_c']['labelValue']='Communication ProspectPrimary Lead';
$dictionary['Opportunity']['fields']['communication_prospectprimar_c']['dependency']='';

 ?>